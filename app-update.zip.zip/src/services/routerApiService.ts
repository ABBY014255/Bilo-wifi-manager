import { Capacitor, CapacitorHttp } from '@capacitor/core';
import {
  ConnectionBand,
  ConnectedDevice,
  DiagnosticStep,
  FirewallFilterMode,
  FirewallRule,
  RouterConfig,
  RouterFirmwareProtocol,
  RouterNetworkInfo,
  RouterTestResult,
} from '../types';

/**
 * RouterApiService
 * Direct native Android / Capacitor ZLT & Tozed CPE Router integration engine.
 *
 * - Uses `CapacitorHttp` from `@capacitor/core` for direct HTTP GET/POST to any private LAN
 *   gateway IP (192.168.1.1, 192.168.0.1, 192.168.8.1, or any custom private IPv4 address),
 *   bypassing Android WebView CORS and Mixed Content restrictions with zero PC/Node.js bridge.
 * - Captures `Set-Cookie` session headers from login responses and attaches `Cookie`,
 *   `Referer: http://<gateway>/index.html`, and `Origin: http://<gateway>` to all subsequent calls.
 * - Auto-detects across ZLT/Tozed CPE firmware variants:
 *     Variant A (`goform`): /goform/goform_set_cmd_process & /goform/goform_get_cmd_process
 *     Variant B (`reqproc`): /reqproc/proc_post & /reqproc/proc_get
 *     Variant C (`tozed_web`): /api/login, /cgi-bin/luci, /cgi-bin/http.cgi
 * - Supports full router management: Connected Devices, MAC Filtering/Blocking,
 *   Wi-Fi SSID & Password updates, Signal/Network Info, and Router Reboot.
 */

interface NormalizedResponse {
  status: number;
  ok: boolean;
  text: string;
  json: Record<string, unknown> | null;
  headers: Record<string, string>;
  url?: string;
  location?: string;
  capturedCookie: boolean;
  capturedStok?: string;
}

type ResolvedVariant = Exclude<RouterFirmwareProtocol, 'auto'>;
type VariantCSubmode =
  | 'cgi_login'
  | 'boafrm'
  | 'action_login'
  | 'login_html_token'
  | 'api_login'
  | 'luci'
  | 'http_cgi';

interface LoginHtmlMetadata {
  ld?: string;
  csrfToken?: string;
  csrfFieldName?: string;
  salt?: string;
  formAction?: string;
  usesSha256: boolean;
  usesMd5: boolean;
}

const INITIAL_DEMO_DEVICES: ConnectedDevice[] = [
  {
    id: 'dev-1',
    hostname: 'iPhone-14-Pro',
    ipAddress: '192.168.1.101',
    macAddress: 'A4:83:E7:2B:91:0C',
    connectionType: '5GHz',
    online: true,
    signalStrength: -48,
    connectedSince: Date.now() - 4 * 60 * 60 * 1000,
  },
  {
    id: 'dev-2',
    hostname: 'Galaxy-A15-Juma',
    ipAddress: '192.168.1.104',
    macAddress: '7C:2A:31:F4:88:12',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -61,
    connectedSince: Date.now() - 3 * 60 * 60 * 1000,
  },
  {
    id: 'dev-3',
    hostname: 'TECNO-SPARK-20',
    ipAddress: '192.168.1.108',
    macAddress: 'B8:53:AC:60:4D:71',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -57,
    connectedSince: Date.now() - 58 * 60 * 1000,
  },
  {
    id: 'dev-4',
    hostname: 'LG-WebOS-SmartTV',
    ipAddress: '192.168.1.112',
    macAddress: 'CC:2D:83:41:5E:19',
    connectionType: 'LAN',
    online: true,
    connectedSince: Date.now() - 18 * 60 * 60 * 1000,
  },
  {
    id: 'dev-5',
    hostname: 'HP-Pavilion-Baraka',
    ipAddress: '192.168.1.115',
    macAddress: 'D8:F2:CA:19:03:AF',
    connectionType: '5GHz',
    online: true,
    signalStrength: -52,
    connectedSince: Date.now() - 2 * 60 * 60 * 1000,
  },
  {
    id: 'dev-6',
    hostname: 'Redmi-13C-Guest',
    ipAddress: '192.168.1.121',
    macAddress: '50:8E:49:9D:33:E4',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -66,
    connectedSince: Date.now() - 19 * 60 * 1000,
  },
  {
    id: 'dev-7',
    hostname: 'Infinix-HOT-40i',
    ipAddress: '192.168.1.129',
    macAddress: '24:4B:FE:A1:77:05',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -64,
    connectedSince: Date.now() - 11 * 60 * 1000,
  },
];

const SIMULATED_POOL: Array<{ hostname: string; macAddress: string; connectionType: ConnectionBand }> = [
  { hostname: 'Samsung-Galaxy-A05', macAddress: '8C:F5:A3:44:21:9E', connectionType: '2.4GHz' },
  { hostname: 'iPhone-12-Mini', macAddress: 'F0:18:98:7C:55:B2', connectionType: '5GHz' },
  { hostname: 'TECNO-CAMON-30', macAddress: '64:A2:F9:1E:08:D3', connectionType: '5GHz' },
  { hostname: 'Lenovo-ThinkPad-T14', macAddress: '00:1A:79:B2:46:81', connectionType: 'LAN' },
  { hostname: 'OPPO-A38-Client', macAddress: 'AC:37:43:D9:14:6B', connectionType: '2.4GHz' },
];

const COMMON_GATEWAYS = ['192.168.1.1', '192.168.0.1', '192.168.8.1', '192.168.100.1'] as const;

// Validates RFC1918 private IPv4 addresses (10.x.x.x, 172.16-31.x.x, 192.168.x.x) with optional :port
const PRIVATE_IPV4_RE =
  /^(192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})(:\d{1,5})?$/;

export function isNativeCapacitorRuntime(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

export function cleanGatewayHost(raw: string): string {
  return raw.trim().replace(/^https?:\/\//i, '').replace(/\/+$/, '');
}

/**
 * Validates that the gateway is a valid private LAN IPv4 address (each octet 0-255, optional port 1-65535).
 */
export function isValidGatewayHost(raw: string): boolean {
  const cleaned = cleanGatewayHost(raw);
  if (!PRIVATE_IPV4_RE.test(cleaned)) return false;
  const [ipPart, portPart] = cleaned.split(':');
  const octets = ipPart.split('.').map(Number);
  if (octets.length !== 4 || octets.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) {
    return false;
  }
  if (portPart !== undefined) {
    const port = Number(portPart);
    if (!Number.isInteger(port) || port < 1 || port > 65535) return false;
  }
  return true;
}

function safeBase64(input: string): string {
  try {
    const bytes = new TextEncoder().encode(input);
    let binary = '';
    bytes.forEach((b) => {
      binary += String.fromCharCode(b);
    });
    return btoa(binary);
  } catch {
    return btoa(input);
  }
}

/**
 * Pure-TypeScript SHA-256 (FIPS 180-4) so ZLT/Tozed `LD` salted password hashing
 * works reliably inside HTTP Android WebViews where `crypto.subtle` may be unavailable.
 */
const SHA256_K = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

function sha256Hex(input: string): string {
  const bytes = new TextEncoder().encode(input);
  const bitLen = bytes.length * 8;
  const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
  const buf = new Uint8Array(paddedLen);
  buf.set(bytes);
  buf[bytes.length] = 0x80;
  const view = new DataView(buf.buffer);
  view.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000), false);
  view.setUint32(paddedLen - 4, bitLen >>> 0, false);

  let h0 = 0x6a09e667;
  let h1 = 0xbb67ae85;
  let h2 = 0x3c6ef372;
  let h3 = 0xa54ff53a;
  let h4 = 0x510e527f;
  let h5 = 0x9b05688c;
  let h6 = 0x1f83d9ab;
  let h7 = 0x5be0cd19;

  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLen; offset += 64) {
    for (let i = 0; i < 16; i++) {
      w[i] = view.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i++) {
      const s0 =
        ((w[i - 15] >>> 7) | (w[i - 15] << 25)) ^
        ((w[i - 15] >>> 18) | (w[i - 15] << 14)) ^
        (w[i - 15] >>> 3);
      const s1 =
        ((w[i - 2] >>> 17) | (w[i - 2] << 15)) ^
        ((w[i - 2] >>> 19) | (w[i - 2] << 13)) ^
        (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }

    let a = h0;
    let b = h1;
    let c = h2;
    let d = h3;
    let e = h4;
    let f = h5;
    let g = h6;
    let h = h7;

    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + SHA256_K[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    h0 = (h0 + a) >>> 0;
    h1 = (h1 + b) >>> 0;
    h2 = (h2 + c) >>> 0;
    h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0;
    h5 = (h5 + f) >>> 0;
    h6 = (h6 + g) >>> 0;
    h7 = (h7 + h) >>> 0;
  }

  return [h0, h1, h2, h3, h4, h5, h6, h7]
    .map((n) => n.toString(16).padStart(8, '0'))
    .join('');
}

/**
 * Pure-TypeScript MD5 (RFC 1321) for legacy CPE routers that require MD5 password hashing.
 */
const MD5_S = [
  7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
  5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
  4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
  6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
];

const MD5_K = Array.from({ length: 64 }, (_, i) =>
  Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0
);

function md5Hex(input: string): string {
  const bytes = new TextEncoder().encode(input);
  const bitLen = bytes.length * 8;
  const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
  const buf = new Uint8Array(paddedLen);
  buf.set(bytes);
  buf[bytes.length] = 0x80;
  const view = new DataView(buf.buffer);
  view.setUint32(paddedLen - 8, bitLen >>> 0, true);
  view.setUint32(paddedLen - 4, Math.floor(bitLen / 0x100000000), true);

  let a0 = 0x67452301;
  let b0 = 0xefcdab89;
  let c0 = 0x98badcfe;
  let d0 = 0x10325476;

  const m = new Uint32Array(16);
  for (let offset = 0; offset < paddedLen; offset += 64) {
    for (let i = 0; i < 16; i++) {
      m[i] = view.getUint32(offset + i * 4, true);
    }

    let a = a0;
    let b = b0;
    let c = c0;
    let d = d0;

    for (let i = 0; i < 64; i++) {
      let f = 0;
      let g = 0;
      if (i < 16) {
        f = (b & c) | (~b & d);
        g = i;
      } else if (i < 32) {
        f = (d & b) | (~d & c);
        g = (5 * i + 1) % 16;
      } else if (i < 48) {
        f = b ^ c ^ d;
        g = (3 * i + 5) % 16;
      } else {
        f = c ^ (b | ~d);
        g = (7 * i) % 16;
      }
      const sum = (a + f + MD5_K[i] + m[g]) >>> 0;
      a = d;
      d = c;
      c = b;
      const rot = (sum << MD5_S[i]) | (sum >>> (32 - MD5_S[i]));
      b = (b + rot) >>> 0;
    }

    a0 = (a0 + a) >>> 0;
    b0 = (b0 + b) >>> 0;
    c0 = (c0 + c) >>> 0;
    d0 = (d0 + d) >>> 0;
  }

  const out = new Uint8Array(16);
  const outView = new DataView(out.buffer);
  outView.setUint32(0, a0, true);
  outView.setUint32(4, b0, true);
  outView.setUint32(8, c0, true);
  outView.setUint32(12, d0, true);
  return Array.from(out)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function parseJsonSafe(raw: string): Record<string, unknown> | null {
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return parsed as Record<string, unknown>;
    }
    return null;
  } catch {
    return null;
  }
}

function getHeaderCaseInsensitive(
  headers: Record<string, unknown> | undefined,
  name: string
): unknown {
  if (!headers) return undefined;
  const target = name.toLowerCase();
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === target) return value;
  }
  return undefined;
}

function extractStokToken(
  json: Record<string, unknown> | null,
  text: string,
  location?: string,
  url?: string
): string | undefined {
  const fromJson = json?.stok ?? json?.token ?? json?.sessionId ?? json?.sid;
  if (typeof fromJson === 'string' && /^[A-Za-z0-9._-]{6,128}$/.test(fromJson.trim())) {
    return fromJson.trim();
  }

  for (const source of [location, url, text]) {
    if (!source) continue;
    const stokMatch =
      source.match(/[;?&/]stok=([A-Za-z0-9._-]{6,128})/i) ||
      source.match(/["']stok["']\s*[:=]\s*["']([A-Za-z0-9._-]{6,128})["']/i);
    if (stokMatch?.[1]) return stokMatch[1];
  }

  return undefined;
}

/**
 * Safely parses `/login.html` text via regex (no DOM injection or script execution)
 * to discover hidden `LD` salt, `csrf_token`, form action path, and hash hints.
 */
function parseLoginHtmlMetadata(html: string): LoginHtmlMetadata {
  const result: LoginHtmlMetadata = {
    usesSha256: /sha256|SHA256|hex_sha256/i.test(html),
    usesMd5: /\bmd5\b|hex_md5|MD5/i.test(html),
  };

  // Hidden/script LD salt (common on Airtel Tanzania ZLT / Tozed CPE routers)
  const ldMatch =
    html.match(/<input[^>]*name=["']LD["'][^>]*value=["']([^"']+)["']/i) ||
    html.match(/<input[^>]*value=["']([^"']+)["'][^>]*name=["']LD["']/i) ||
    html.match(/\b(?:var|let|const)?\s*LD\s*=\s*["']([A-Za-z0-9+/=._-]{4,128})["']/);
  if (ldMatch?.[1]) {
    result.ld = ldMatch[1].trim();
  }

  // Hidden/meta/script CSRF token or anti-CSRF field
  const csrfPatterns: Array<{ re: RegExp; fieldName: string }> = [
    { re: /<input[^>]*name=["'](csrf_token|_csrf|csrfToken|token|AD)["'][^>]*value=["']([^"']+)["']/i, fieldName: '' },
    { re: /<input[^>]*value=["']([^"']+)["'][^>]*name=["'](csrf_token|_csrf|csrfToken|token|AD)["']/i, fieldName: '' },
    { re: /<meta[^>]*name=["']csrf-token["'][^>]*content=["']([^"']+)["']/i, fieldName: 'csrf_token' },
    { re: /\b(?:csrf_token|csrfToken)\s*[:=]\s*["']([A-Za-z0-9+/=._-]{6,128})["']/i, fieldName: 'csrf_token' },
  ];

  for (const { re, fieldName } of csrfPatterns) {
    const match = html.match(re);
    if (match) {
      if (fieldName) {
        result.csrfFieldName = fieldName;
        result.csrfToken = match[1]?.trim();
      } else if (re.source.includes('name=["\'](') && re.source.indexOf('name=') < re.source.indexOf('value=')) {
        result.csrfFieldName = match[1]?.trim();
        result.csrfToken = match[2]?.trim();
      } else {
        result.csrfToken = match[1]?.trim();
        result.csrfFieldName = match[2]?.trim();
      }
      if (result.csrfToken) break;
    }
  }

  // Generic salt / nonce / rand challenge
  const saltMatch =
    html.match(/<input[^>]*name=["'](?:salt|nonce|rand|challenge)["'][^>]*value=["']([^"']+)["']/i) ||
    html.match(/\b(?:salt|nonce|challenge)\s*[:=]\s*["']([A-Za-z0-9+/=._-]{4,128})["']/i);
  if (saltMatch?.[1]) {
    result.salt = saltMatch[1].trim();
  }

  // Safe relative <form action="/..."> path on the same router gateway
  const formActionMatch = html.match(/<form[^>]*action=["']([^"']+)["']/i);
  if (formActionMatch?.[1]) {
    const candidate = formActionMatch[1].trim();
    if (/^\/[A-Za-z0-9/_.-]{1,120}$/.test(candidate)) {
      result.formAction = candidate;
    }
  }

  return result;
}

class RouterApiService {
  private demoDevices: ConnectedDevice[] = [...INITIAL_DEMO_DEVICES];
  private poolIndex = 0;
  private demoSsid = 'Bilo_WiFi_2.4G';

  private resolvedProtocolByGateway = new Map<string, ResolvedVariant>();
  private resolvedVariantCSubmode = new Map<string, VariantCSubmode>();
  private resolvedVariantLabelByGateway = new Map<string, string>();
  private lastLoginAtByGateway = new Map<string, number>();

  // In-memory per-gateway session state (never persisted to disk/localStorage)
  private sessionCookieJar = new Map<string, Map<string, string>>();
  private sessionStokByGateway = new Map<string, string>();
  private sessionCsrfByGateway = new Map<string, string>();
  private loginRefererByGateway = new Map<string, string>();

  private getGatewayBaseUrl(gatewayIp: string): string {
    return `http://${cleanGatewayHost(gatewayIp)}`;
  }

  private isBrowserHttpsBlocked(): boolean {
    if (isNativeCapacitorRuntime()) return false;
    return typeof window !== 'undefined' && window.location.protocol === 'https:';
  }

  private captureSetCookies(gateway: string, headers?: Record<string, unknown>): boolean {
    if (!headers) return false;
    const rawSetCookie = getHeaderCaseInsensitive(headers, 'set-cookie');
    if (!rawSetCookie) return false;

    const rawList: string[] = Array.isArray(rawSetCookie)
      ? rawSetCookie.map((v) => String(v))
      : [String(rawSetCookie)];

    let jar = this.sessionCookieJar.get(gateway);
    if (!jar) {
      jar = new Map<string, string>();
      this.sessionCookieJar.set(gateway, jar);
    }

    let capturedAny = false;
    for (const headerLine of rawList) {
      // Split multiple Set-Cookie entries without splitting on Expires=Day, DD MMM YYYY GMT
      const entries = headerLine.split(/,(?=\s*[A-Za-z0-9_.-]+=)/);
      for (const rawCookie of entries) {
        const firstSegment = rawCookie.split(';')[0]?.trim();
        const eqIdx = firstSegment?.indexOf('=') ?? -1;
        if (firstSegment && eqIdx > 0) {
          const name = firstSegment.slice(0, eqIdx).trim();
          const value = firstSegment.slice(eqIdx + 1).trim();
          if (name && value && value.toLowerCase() !== 'deleted') {
            jar.set(name, value);
            capturedAny = true;
          }
        }
      }
    }

    return capturedAny;
  }

  private getCookieHeader(gateway: string): string {
    const jar = this.sessionCookieJar.get(gateway);
    if (!jar || jar.size === 0) return '';
    return Array.from(jar.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }

  private clearGatewaySession(gateway: string): void {
    this.lastLoginAtByGateway.delete(gateway);
    this.sessionCookieJar.delete(gateway);
    this.sessionStokByGateway.delete(gateway);
    this.sessionCsrfByGateway.delete(gateway);
  }

  /**
   * Direct router HTTP transport powered by `CapacitorHttp` from `@capacitor/core`.
   * Automatically attaches `Cookie` (from captured `Set-Cookie`), `Referer`, `Origin`,
   * and `X-CSRF-Token` (when present) on every request to keep the router session authenticated.
   */
  private async sendRouterRequest(
    config: RouterConfig,
    routerPath: string,
    options: {
      method: 'GET' | 'POST';
      body?: string;
      contentType?: string;
      timeoutMs?: number;
      gatewayOverride?: string;
      refererPath?: string;
      disableRedirects?: boolean;
      extraHeaders?: Record<string, string>;
    }
  ): Promise<NormalizedResponse> {
    const gateway = cleanGatewayHost(options.gatewayOverride ?? config.gatewayIp);
    const baseUrl = this.getGatewayBaseUrl(gateway);
    const url = `${baseUrl}${routerPath}`;
    const timeoutMs = options.timeoutMs ?? 5000;
    const cookieHeader = this.getCookieHeader(gateway);
    const csrfToken = this.sessionCsrfByGateway.get(gateway);
    const refererPath = options.refererPath ?? this.loginRefererByGateway.get(gateway) ?? '/login.html';

    const requestHeaders: Record<string, string> = {
      Referer: `${baseUrl}${refererPath}`,
      Origin: baseUrl,
      ...(options.method === 'POST'
        ? {
            'Content-Type':
              options.contentType ?? 'application/x-www-form-urlencoded; charset=UTF-8',
          }
        : {}),
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
      ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
      ...(options.extraHeaders ?? {}),
    };

    // Native Android / iOS Capacitor runtime: use CapacitorHttp directly (zero CORS/Mixed Content)
    if (isNativeCapacitorRuntime()) {
      const response = await CapacitorHttp.request({
        url,
        method: options.method,
        headers: requestHeaders,
        data: options.body,
        connectTimeout: timeoutMs,
        readTimeout: timeoutMs,
        shouldEncodeUrlParams: false,
        ...(options.disableRedirects ? { disableRedirects: true } : {}),
      });

      const rawHeaders = (response.headers ?? {}) as Record<string, unknown>;
      const capturedCookie = this.captureSetCookies(gateway, rawHeaders);

      const normalizedHeaders: Record<string, string> = {};
      for (const [k, v] of Object.entries(rawHeaders)) {
        normalizedHeaders[k.toLowerCase()] = Array.isArray(v) ? v.join(', ') : String(v ?? '');
      }

      const text =
        typeof response.data === 'string'
          ? response.data
          : response.data != null
            ? JSON.stringify(response.data)
            : '';
      const json =
        response.data && typeof response.data === 'object'
          ? (response.data as Record<string, unknown>)
          : parseJsonSafe(text);

      const location = normalizedHeaders['location'];
      const capturedStok = extractStokToken(json, text, location, response.url);
      if (capturedStok) {
        this.sessionStokByGateway.set(gateway, capturedStok);
      }

      return {
        status: response.status,
        ok: response.status >= 200 && response.status < 400,
        text,
        json,
        headers: normalizedHeaders,
        url: response.url,
        location,
        capturedCookie,
        capturedStok,
      };
    }

    // Standard web fallback (works directly when opened over local HTTP LAN)
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        method: options.method,
        credentials: 'include',
        redirect: options.disableRedirects ? 'manual' : 'follow',
        headers:
          options.method === 'POST'
            ? {
                'Content-Type':
                  options.contentType ?? 'application/x-www-form-urlencoded; charset=UTF-8',
                ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
              }
            : undefined,
        body: options.body,
        signal: controller.signal,
      });
      window.clearTimeout(timer);
      const text = await res.text();
      const json = parseJsonSafe(text);
      const location = res.headers.get('location') ?? undefined;
      const capturedStok = extractStokToken(json, text, location, res.url);
      if (capturedStok) {
        this.sessionStokByGateway.set(gateway, capturedStok);
      }
      return {
        status: res.status,
        ok: res.status >= 200 && res.status < 400,
        text,
        json,
        headers: location ? { location } : {},
        url: res.url,
        location,
        capturedCookie: false,
        capturedStok,
      };
    } catch (err) {
      window.clearTimeout(timer);
      throw err;
    }
  }

  /**
   * Probes common private LAN gateway IPs (192.168.1.1, 192.168.0.1, 192.168.8.1, 192.168.100.1)
   * directly via CapacitorHttp to discover the connected ZLT/Tozed router.
   */
  async detectGatewayIp(
    config: RouterConfig
  ): Promise<{ foundIp: string | null; blockedByHttps?: boolean }> {
    if (this.isBrowserHttpsBlocked()) {
      return { foundIp: null, blockedByHttps: true };
    }

    const candidates = Array.from(
      new Set([cleanGatewayHost(config.gatewayIp), ...COMMON_GATEWAYS].filter(isValidGatewayHost))
    );

    for (const ip of candidates) {
      for (const probePath of ['/login.html', '/index.html']) {
        try {
          const res = await this.sendRouterRequest(config, probePath, {
            method: 'GET',
            timeoutMs: 2000,
            gatewayOverride: ip,
            refererPath: probePath,
          });
          if (res.status > 0 && res.status < 400) {
            this.loginRefererByGateway.set(ip, probePath);
            return { foundIp: ip };
          }
        } catch {
          // try next path / gateway candidate
        }
      }
    }
    return { foundIp: null };
  }

  private isGoformLoginSuccess(res: NormalizedResponse): boolean {
    const resultVal = String(res.json?.result ?? '').trim().toLowerCase();
    const lowerText = res.text.toLowerCase();
    return (
      resultVal === '0' ||
      resultVal === '4' ||
      resultVal === 'success' ||
      lowerText.includes('"result":"0"') ||
      lowerText.includes('"result":0') ||
      lowerText.includes('"result":"success"') ||
      (res.status === 200 && lowerText.includes('success') && !lowerText.includes('fail') && !lowerText.includes('error'))
    );
  }

  private isGoformLoginRejected(res: NormalizedResponse): boolean {
    const resultVal = String(res.json?.result ?? '').trim().toLowerCase();
    return (
      resultVal === '3' ||
      resultVal === '1' ||
      resultVal === '2' ||
      resultVal === 'failure' ||
      resultVal === 'error'
    );
  }

  /**
   * Method A: Standard ZLT / Tozed `goform` LOGIN (and `reqproc` when selected).
   * POST `/goform/goform_set_cmd_process` with `goformId=LOGIN`, `isTest=false`,
   * Base64-encoded `password` (`btoa(password)`), plus plain-text fallback,
   * sending `Referer: http://<gateway>/login.html` and storing `Set-Cookie`.
   */
  private async loginGoformOrReqproc(
    config: RouterConfig,
    variant: 'goform' | 'reqproc'
  ): Promise<{ ok: boolean; authRejected?: boolean; variantLabel?: string; detail?: string }> {
    const username = config.username.trim() || 'admin';
    const plainPassword = config.password || 'admin';
    const base64Password = safeBase64(plainPassword);
    const postPath =
      variant === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';

    const candidates =
      base64Password !== plainPassword
        ? [
            { value: base64Password, encoding: 'base64' },
            { value: plainPassword, encoding: 'plain' },
          ]
        : [{ value: plainPassword, encoding: 'plain' }];

    let sawAuthReject = false;

    for (const candidate of candidates) {
      const loginBody = new URLSearchParams({
        isTest: 'false',
        goformId: 'LOGIN',
        username,
        password: candidate.value,
      }).toString();

      let res: NormalizedResponse;
      try {
        res = await this.sendRouterRequest(config, postPath, {
          method: 'POST',
          body: loginBody,
          refererPath: '/login.html',
        });
      } catch {
        return { ok: false, detail: `${postPath} unreachable` };
      }

      if (res.status === 404 || res.status === 405 || res.status >= 500) {
        return { ok: false, detail: `${postPath} HTTP ${res.status}` };
      }

      if (this.isGoformLoginSuccess(res)) {
        const label =
          variant === 'goform'
            ? `Method A · ZLT/Tozed goform (${candidate.encoding})`
            : `ZLT / Airtel reqproc (${candidate.encoding})`;
        return { ok: true, variantLabel: label, detail: `${postPath} (${candidate.encoding})` };
      }

      if (this.isGoformLoginRejected(res)) {
        sawAuthReject = true;
        continue;
      }
    }

    return {
      ok: false,
      authRejected: sawAuthReject,
      detail: sawAuthReject ? 'Rejected (base64 & plain)' : `${postPath} unsupported`,
    };
  }

  /**
   * Method B: Airtel Tanzania Tozed/ZLT CGI / Boa / Action form login endpoints.
   * POST to `/cgi-bin/login.cgi`, `/boafrm/formLogin`, or `/action/login`
   * with form-urlencoded `username` & `password` (Base64 and plain text),
   * capturing `Set-Cookie` session cookie or `stok` token.
   */
  private async loginCgiBoaAction(
    config: RouterConfig
  ): Promise<{
    ok: boolean;
    authRejected?: boolean;
    submode?: VariantCSubmode;
    variantLabel?: string;
    detail?: string;
  }> {
    const username = config.username.trim() || 'admin';
    const plainPassword = config.password || 'admin';
    const base64Password = safeBase64(plainPassword);
    let sawAuthReject = false;

    const endpoints: Array<{
      path: string;
      submode: VariantCSubmode;
      label: string;
      extraFields?: Record<string, string>;
    }> = [
      { path: '/cgi-bin/login.cgi', submode: 'cgi_login', label: 'Method B · /cgi-bin/login.cgi' },
      {
        path: '/boafrm/formLogin',
        submode: 'boafrm',
        label: 'Method B · /boafrm/formLogin',
        extraFields: { 'submit-url': '/index.html' },
      },
      { path: '/action/login', submode: 'action_login', label: 'Method B · /action/login' },
    ];

    const passwordCandidates =
      base64Password !== plainPassword
        ? [
            { value: base64Password, encoding: 'base64' },
            { value: plainPassword, encoding: 'plain' },
          ]
        : [{ value: plainPassword, encoding: 'plain' }];

    for (const ep of endpoints) {
      for (const candidate of passwordCandidates) {
        const body = new URLSearchParams({
          username,
          password: candidate.value,
          ...(ep.extraFields ?? {}),
        }).toString();

        let res: NormalizedResponse;
        try {
          res = await this.sendRouterRequest(config, ep.path, {
            method: 'POST',
            body,
            refererPath: '/login.html',
            disableRedirects: true,
          });
        } catch {
          break;
        }

        if (res.status === 404 || res.status === 405 || res.status >= 500) {
          break;
        }

        const lowerText = res.text.toLowerCase();
        const lowerLocation = (res.location ?? '').toLowerCase();
        const resultVal = String(res.json?.result ?? res.json?.code ?? '').trim().toLowerCase();

        const hasFailureMarker =
          res.status === 401 ||
          res.status === 403 ||
          res.json?.success === false ||
          res.json?.ok === false ||
          resultVal === '1' ||
          resultVal === '3' ||
          resultVal === 'fail' ||
          resultVal === 'error' ||
          lowerText.includes('invalid password') ||
          lowerText.includes('wrong password') ||
          lowerText.includes('incorrect password') ||
          lowerText.includes('login failed') ||
          lowerText.includes('authentication failed') ||
          lowerLocation.includes('login.html') ||
          lowerLocation.includes('err=');

        const redirectedToDashboard =
          (res.status === 301 || res.status === 302 || res.status === 303) &&
          Boolean(res.location) &&
          !lowerLocation.includes('login.html') &&
          !lowerLocation.includes('error');

        const positiveJson =
          res.json?.success === true ||
          res.json?.ok === true ||
          resultVal === '0' ||
          resultVal === 'success' ||
          Boolean(res.capturedStok);

        const acceptedWithCookie =
          res.capturedCookie &&
          (res.status === 200 || res.status === 302) &&
          !hasFailureMarker &&
          !lowerText.includes('name="password"');

        if (!hasFailureMarker && (positiveJson || redirectedToDashboard || acceptedWithCookie)) {
          return {
            ok: true,
            submode: ep.submode,
            variantLabel: `${ep.label} (${candidate.encoding})`,
            detail: res.capturedStok ? `stok captured` : `${ep.path} OK`,
          };
        }

        if (hasFailureMarker) {
          sawAuthReject = true;
        }
      }
    }

    return {
      ok: false,
      authRejected: sawAuthReject,
      detail: sawAuthReject ? 'CGI/Boa/Action login rejected' : 'CGI/Boa/Action endpoints not found',
    };
  }

  /**
   * Method C: Fetch `/login.html` first to read any hidden token/salt (`LD` or `csrf_token`),
   * hash `password` (SHA-256 / MD5) if required, and submit the login request with
   * `Referer: http://<gateway>/login.html` and `Origin: http://<gateway>` headers.
   */
  private async loginViaLoginHtmlToken(
    config: RouterConfig
  ): Promise<{
    ok: boolean;
    authRejected?: boolean;
    protocol: ResolvedVariant;
    submode?: VariantCSubmode;
    variantLabel?: string;
    detail?: string;
  }> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const username = config.username.trim() || 'admin';
    const plainPassword = config.password || 'admin';
    const base64Password = safeBase64(plainPassword);
    let sawAuthReject = false;

    // Step C1: Fetch /login.html to extract hidden LD / csrf_token / salt / form action & initial cookies
    let meta: LoginHtmlMetadata = { usesSha256: false, usesMd5: false };
    try {
      const htmlRes = await this.sendRouterRequest(config, '/login.html', {
        method: 'GET',
        refererPath: '/login.html',
        timeoutMs: 3500,
      });
      if (htmlRes.status >= 200 && htmlRes.status < 400 && htmlRes.text) {
        this.loginRefererByGateway.set(gateway, '/login.html');
        meta = parseLoginHtmlMetadata(htmlRes.text);
      }
    } catch {
      // continue to LD endpoint probe
    }

    // Step C2: Probe standard ZLT/Tozed dynamic LD salt endpoint if LD wasn't embedded in /login.html
    if (!meta.ld) {
      try {
        const ldRes = await this.sendRouterRequest(
          config,
          '/goform/goform_get_cmd_process?isTest=false&cmd=LD',
          {
            method: 'GET',
            refererPath: '/login.html',
            timeoutMs: 3000,
          }
        );
        const ldVal = String(ldRes.json?.LD ?? '').trim();
        if (ldVal && ldVal.length >= 4) {
          meta.ld = ldVal;
          meta.usesSha256 = true;
        }
      } catch {
        // ignore if router doesn't expose cmd=LD
      }
    }

    if (meta.csrfToken) {
      this.sessionCsrfByGateway.set(gateway, meta.csrfToken);
    }

    const salt = meta.ld || meta.salt;
    const shaPassUpper = sha256Hex(plainPassword).toUpperCase();
    const shaPassLower = sha256Hex(plainPassword);
    const md5PassLower = md5Hex(plainPassword);

    // Build ordered hashed/encoded password candidates based on discovered salt / hash hints
    const passwordPayloads: Array<{ value: string; label: string }> = [];
    if (salt) {
      // Standard ZLT/Tozed TZLink formula: SHA256(SHA256(password).toUpperCase() + LD).toUpperCase()
      passwordPayloads.push({
        value: sha256Hex(shaPassUpper + salt).toUpperCase(),
        label: 'sha256(sha256+LD)',
      });
      passwordPayloads.push({
        value: sha256Hex(plainPassword + salt).toUpperCase(),
        label: 'sha256(pass+LD)',
      });
      passwordPayloads.push({
        value: sha256Hex(plainPassword + salt),
        label: 'sha256-lower(pass+LD)',
      });
      passwordPayloads.push({
        value: md5Hex(plainPassword + salt),
        label: 'md5(pass+salt)',
      });
      passwordPayloads.push({
        value: md5Hex(md5PassLower + salt),
        label: 'md5(md5+salt)',
      });
    } else if (meta.usesSha256) {
      passwordPayloads.push({ value: shaPassUpper, label: 'sha256-upper' });
      passwordPayloads.push({ value: shaPassLower, label: 'sha256' });
    } else if (meta.usesMd5) {
      passwordPayloads.push({ value: md5PassLower, label: 'md5' });
    }

    // Always include base64 & plain if CSRF token or custom form action was found
    if (meta.csrfToken || meta.formAction) {
      passwordPayloads.push({ value: base64Password, label: 'base64' });
      passwordPayloads.push({ value: plainPassword, label: 'plain' });
    }

    if (passwordPayloads.length === 0) {
      return {
        ok: false,
        protocol: 'goform',
        detail: 'No LD/csrf_token or hash requirement found in /login.html',
      };
    }

    const extraTokenFields: Record<string, string> = {};
    if (meta.csrfToken) {
      extraTokenFields[meta.csrfFieldName || 'csrf_token'] = meta.csrfToken;
    }
    if (meta.ld) {
      extraTokenFields.LD = meta.ld;
    }

    // Step C3: Submit to /goform/goform_set_cmd_process with LD/CSRF hash (standard ZLT/Tozed)
    if (salt || meta.csrfToken) {
      for (const candidate of passwordPayloads) {
        const body = new URLSearchParams({
          isTest: 'false',
          goformId: 'LOGIN',
          username,
          password: candidate.value,
          ...extraTokenFields,
        }).toString();

        try {
          const res = await this.sendRouterRequest(config, '/goform/goform_set_cmd_process', {
            method: 'POST',
            body,
            refererPath: '/login.html',
          });
          if (res.status === 404 || res.status === 405 || res.status >= 500) break;

          if (this.isGoformLoginSuccess(res)) {
            return {
              ok: true,
              protocol: 'goform',
              variantLabel: `Method C · /login.html (${candidate.label})`,
              detail: `goform + ${candidate.label}`,
            };
          }
          if (this.isGoformLoginRejected(res)) {
            sawAuthReject = true;
          }
        } catch {
          break;
        }
      }
    }

    // Step C4: Submit to discovered <form action="..."> or standard CGI/Boa/Action paths with token/hash
    const submitPaths = Array.from(
      new Set(
        [
          meta.formAction,
          '/cgi-bin/login.cgi',
          '/boafrm/formLogin',
          '/action/login',
        ].filter((p): p is string => Boolean(p) && p !== '/goform/goform_set_cmd_process')
      )
    );

    for (const submitPath of submitPaths) {
      for (const candidate of passwordPayloads) {
        const body = new URLSearchParams({
          username,
          password: candidate.value,
          ...extraTokenFields,
        }).toString();

        try {
          const res = await this.sendRouterRequest(config, submitPath, {
            method: 'POST',
            body,
            refererPath: '/login.html',
            disableRedirects: true,
          });
          if (res.status === 404 || res.status === 405 || res.status >= 500) break;

          const lowerText = res.text.toLowerCase();
          const lowerLocation = (res.location ?? '').toLowerCase();
          const resultVal = String(res.json?.result ?? res.json?.code ?? '').trim().toLowerCase();
          const failed =
            res.status === 401 ||
            res.status === 403 ||
            res.json?.success === false ||
            resultVal === '1' ||
            resultVal === '3' ||
            lowerText.includes('invalid') ||
            lowerText.includes('wrong password') ||
            lowerLocation.includes('login.html');

          const succeeded =
            !failed &&
            (Boolean(res.capturedStok) ||
              res.json?.success === true ||
              resultVal === '0' ||
              ((res.status === 301 || res.status === 302) &&
                Boolean(res.location) &&
                !lowerLocation.includes('login.html')) ||
              (res.capturedCookie && res.status === 200 && !lowerText.includes('name="password"')));

          if (succeeded) {
            return {
              ok: true,
              protocol: 'tozed_web',
              submode: 'login_html_token',
              variantLabel: `Method C · ${submitPath} (${candidate.label})`,
              detail: res.capturedStok ? 'stok + cookie captured' : `${submitPath} OK`,
            };
          }
          if (failed) {
            sawAuthReject = true;
          }
        } catch {
          break;
        }
      }
    }

    return {
      ok: false,
      authRejected: sawAuthReject,
      protocol: 'goform',
      detail: sawAuthReject ? 'Hashed /login.html login rejected' : '/login.html token login failed',
    };
  }

  /**
   * Additional Tozed Web/LuCI/CGI fallback: `/api/login`, `/cgi-bin/luci`, `/cgi-bin/http.cgi`.
   */
  private async loginTozedWebApi(
    config: RouterConfig
  ): Promise<{
    ok: boolean;
    authRejected?: boolean;
    submode?: VariantCSubmode;
    variantLabel?: string;
    detail?: string;
  }> {
    const username = config.username.trim() || 'admin';
    const plainPassword = config.password || 'admin';
    const base64Password = safeBase64(plainPassword);
    let sawAuthReject = false;

    // 1: POST /api/login
    for (const payload of [
      { username, password: base64Password },
      { username, password: plainPassword },
    ]) {
      try {
        const res = await this.sendRouterRequest(config, '/api/login', {
          method: 'POST',
          contentType: 'application/json; charset=UTF-8',
          body: JSON.stringify(payload),
          refererPath: '/login.html',
        });
        if (res.status === 404 || res.status === 405 || res.status >= 500) break;
        const okJson =
          res.json?.success === true ||
          res.json?.ok === true ||
          String(res.json?.result ?? '').toLowerCase() === '0' ||
          String(res.json?.code ?? '') === '0' ||
          Boolean(res.capturedStok);
        if (res.status === 200 && okJson) {
          return {
            ok: true,
            submode: 'api_login',
            variantLabel: 'Tozed Web (/api/login)',
            detail: '/api/login OK',
          };
        }
        if (res.status === 401 || res.status === 403 || res.json?.success === false) {
          sawAuthReject = true;
        }
      } catch {
        break;
      }
    }

    // 2: POST /cgi-bin/luci
    try {
      const luciBody = new URLSearchParams({
        luci_username: username,
        luci_password: plainPassword,
      }).toString();
      const res = await this.sendRouterRequest(config, '/cgi-bin/luci', {
        method: 'POST',
        body: luciBody,
        refererPath: '/login.html',
        disableRedirects: true,
      });
      const hasInvalidMsg =
        res.text.toLowerCase().includes('invalid username') ||
        res.text.toLowerCase().includes('invalid password');
      if (
        res.status === 302 ||
        Boolean(res.capturedStok) ||
        (res.status === 200 && !hasInvalidMsg && res.text.includes('luci'))
      ) {
        return {
          ok: true,
          submode: 'luci',
          variantLabel: 'Tozed LuCI (/cgi-bin/luci)',
          detail: res.capturedStok ? 'LuCI stok captured' : `/cgi-bin/luci HTTP ${res.status}`,
        };
      }
      if (hasInvalidMsg || res.status === 403) {
        sawAuthReject = true;
      }
    } catch {
      // continue to http.cgi
    }

    // 3: POST /cgi-bin/http.cgi
    try {
      const res = await this.sendRouterRequest(config, '/cgi-bin/http.cgi', {
        method: 'POST',
        contentType: 'application/json; charset=UTF-8',
        body: JSON.stringify({
          cmd: 100,
          method: 'POST',
          username,
          passwd: base64Password,
          language: 'EN',
        }),
        refererPath: '/login.html',
      });
      if (res.status === 200 && res.json) {
        const success =
          res.json.success === true ||
          String(res.json.result ?? '').toLowerCase() === '0' ||
          String(res.json.result ?? '').toLowerCase() === 'success' ||
          Boolean(res.capturedStok);
        if (success) {
          return {
            ok: true,
            submode: 'http_cgi',
            variantLabel: 'Tozed CGI (/cgi-bin/http.cgi)',
            detail: '/cgi-bin/http.cgi OK',
          };
        }
        if (res.json.success === false || String(res.json.result) === '3') {
          sawAuthReject = true;
        }
      }
    } catch {
      // ignore
    }

    return {
      ok: false,
      authRejected: sawAuthReject,
      detail: sawAuthReject ? 'Credentials rejected' : 'Tozed Web endpoints not found',
    };
  }

  /**
   * Automatically authenticates using the Airtel Tanzania Tozed/ZLT `/login.html` sequence:
   *   1. Method A: `/goform/goform_set_cmd_process` (`goformId=LOGIN`, Base64 + plain)
   *   2. Method B: `/cgi-bin/login.cgi`, `/boafrm/formLogin`, `/action/login` (cookie / `stok`)
   *   3. Method C: Fetch `/login.html` (`LD` / `csrf_token` / salt + SHA-256/MD5 hash)
   *   4. Fallbacks: `reqproc` (`/reqproc/proc_post`) & Tozed Web (`/api/login`, `/cgi-bin/luci`, `/cgi-bin/http.cgi`)
   */
  private async ensureAuthenticated(config: RouterConfig): Promise<{
    ok: boolean;
    protocol: ResolvedVariant;
    variantLabel?: string;
    authRejected?: boolean;
  }> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const cachedProto =
      config.firmwareProtocol !== 'auto'
        ? config.firmwareProtocol
        : this.resolvedProtocolByGateway.get(gateway);
    const lastLogin = this.lastLoginAtByGateway.get(gateway) ?? 0;

    if (cachedProto && Date.now() - lastLogin < 3 * 60 * 1000) {
      return {
        ok: true,
        protocol: cachedProto,
        variantLabel: this.resolvedVariantLabelByGateway.get(gateway),
      };
    }

    let sawAuthRejected = false;

    const recordSuccess = (
      protocol: ResolvedVariant,
      variantLabel: string,
      submode?: VariantCSubmode
    ) => {
      this.resolvedProtocolByGateway.set(gateway, protocol);
      if (submode) this.resolvedVariantCSubmode.set(gateway, submode);
      this.resolvedVariantLabelByGateway.set(gateway, variantLabel);
      this.lastLoginAtByGateway.set(gateway, Date.now());
      return { ok: true, protocol, variantLabel };
    };

    // If user explicitly pinned `reqproc`, try it directly first
    if (config.firmwareProtocol === 'reqproc') {
      const reqRes = await this.loginGoformOrReqproc(config, 'reqproc');
      if (reqRes.ok) {
        return recordSuccess('reqproc', reqRes.variantLabel || 'reqproc');
      }
      return { ok: false, protocol: 'reqproc', authRejected: reqRes.authRejected };
    }

    // Method A: Standard ZLT/Tozed goform LOGIN (Base64 + plain)
    if (config.firmwareProtocol === 'auto' || config.firmwareProtocol === 'goform') {
      const methodA = await this.loginGoformOrReqproc(config, 'goform');
      if (methodA.ok) {
        return recordSuccess('goform', methodA.variantLabel || 'Method A · goform');
      }
      if (methodA.authRejected) sawAuthRejected = true;
    }

    // Method B: /cgi-bin/login.cgi, /boafrm/formLogin, /action/login (cookie / stok capture)
    if (config.firmwareProtocol === 'auto' || config.firmwareProtocol === 'tozed_web') {
      const methodB = await this.loginCgiBoaAction(config);
      if (methodB.ok) {
        return recordSuccess(
          'tozed_web',
          methodB.variantLabel || 'Method B · CGI/Boa Login',
          methodB.submode
        );
      }
      if (methodB.authRejected) sawAuthRejected = true;
    }

    // Method C: Fetch /login.html first to read LD / csrf_token / salt and submit hashed password
    const methodC = await this.loginViaLoginHtmlToken(config);
    if (methodC.ok) {
      return recordSuccess(
        methodC.protocol,
        methodC.variantLabel || 'Method C · /login.html Token Login',
        methodC.submode
      );
    }
    if (methodC.authRejected) sawAuthRejected = true;

    // Fallback 1: Airtel SmartBox reqproc
    if (config.firmwareProtocol === 'auto') {
      const reqRes = await this.loginGoformOrReqproc(config, 'reqproc');
      if (reqRes.ok) {
        return recordSuccess('reqproc', reqRes.variantLabel || 'reqproc');
      }
      if (reqRes.authRejected) sawAuthRejected = true;
    }

    // Fallback 2: Tozed Web /api/login, /cgi-bin/luci, /cgi-bin/http.cgi
    if (config.firmwareProtocol === 'auto' || config.firmwareProtocol === 'tozed_web') {
      const webRes = await this.loginTozedWebApi(config);
      if (webRes.ok) {
        return recordSuccess('tozed_web', webRes.variantLabel || 'tozed_web', webRes.submode);
      }
      if (webRes.authRejected) sawAuthRejected = true;
    }

    return {
      ok: false,
      protocol: cachedProto ?? 'goform',
      authRejected: sawAuthRejected,
    };
  }

  private async queryRouterData(
    config: RouterConfig,
    protocol: ResolvedVariant,
    cmds: string
  ): Promise<Record<string, unknown> | null> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const stok = this.sessionStokByGateway.get(gateway);
    const submode = this.resolvedVariantCSubmode.get(gateway);

    // 1. Standard ZLT/Tozed goform query (also works after Method B/C cookie login on many Airtel TZ routers)
    if (protocol === 'goform' || submode === 'cgi_login' || submode === 'boafrm' || submode === 'action_login' || submode === 'login_html_token') {
      try {
        const res = await this.sendRouterRequest(
          config,
          `/goform/goform_get_cmd_process?isTest=false&cmd=${cmds}&multi_data=1`,
          { method: 'GET' }
        );
        if (res.ok && res.json) return res.json;
      } catch {
        // continue to fallback endpoints below
      }
      if (protocol === 'goform') return null;
    }

    if (protocol === 'reqproc') {
      const res = await this.sendRouterRequest(
        config,
        `/reqproc/proc_get?isTest=false&cmd=${cmds}&multi_data=1`,
        { method: 'GET' }
      );
      if (res.ok && res.json) return res.json;

      const fallbackRes = await this.sendRouterRequest(
        config,
        `/reqproc/proc_get?cmd=${cmds}`,
        { method: 'GET' }
      );
      return fallbackRes.ok && fallbackRes.json ? fallbackRes.json : null;
    }

    // 2. LuCI / stok-authenticated JSON status
    if (submode === 'luci' || stok) {
      const luciPaths = stok
        ? [
            `/cgi-bin/luci/;stok=${encodeURIComponent(stok)}/admin/status/overview?status=1`,
            `/cgi-bin/luci/;stok=${encodeURIComponent(stok)}/admin/network/wireless`,
          ]
        : ['/cgi-bin/luci/admin/status/overview?status=1', '/cgi-bin/luci/admin/network/wireless'];
      for (const path of luciPaths) {
        try {
          const res = await this.sendRouterRequest(config, path, { method: 'GET' });
          if (res.ok && res.json) return res.json;
        } catch {
          // try next
        }
      }
    }

    // 3. REST / Action / CGI DHCP client endpoints (all sending captured Cookie header)
    const restPaths = [
      ...(stok ? [`/action/dhcp_list?stok=${encodeURIComponent(stok)}`] : []),
      '/action/dhcp_list',
      '/api/clients',
      '/api/dhcp/leases',
      '/api/status',
    ];
    for (const path of restPaths) {
      try {
        const res = await this.sendRouterRequest(config, path, { method: 'GET' });
        if (res.ok && res.json) return res.json;
      } catch {
        // try next
      }
    }

    // 4. Tozed CGI JSON RPC
    try {
      const res = await this.sendRouterRequest(config, '/cgi-bin/http.cgi', {
        method: 'POST',
        contentType: 'application/json; charset=UTF-8',
        body: JSON.stringify({
          cmd: 230,
          method: 'GET',
          ...(stok ? { sessionId: stok } : {}),
        }),
      });
      if (res.ok && res.json) return res.json;
    } catch {
      // ignore
    }

    return null;
  }

  private parseNetworkInfo(payload: Record<string, unknown>, fallbackSsid: string): RouterNetworkInfo {
    const ssid24 = String(payload.SSID1 || payload.m_SSID1 || payload.ssid || fallbackSsid).trim();
    const ssid5 = String(payload.SSID2 || payload.wifi_5g_ssid || '').trim() || undefined;
    const networkProvider =
      String(payload.network_provider || payload.spn_name_data || payload.plmn_name || '').trim() ||
      undefined;
    const networkType =
      String(payload.network_type || payload.net_mode || payload.wan_mode || '').trim() ||
      undefined;
    const signalBarRaw = Number(payload.signalbar ?? payload.signal_bar ?? NaN);
    const signalBar = Number.isFinite(signalBarRaw)
      ? Math.max(0, Math.min(5, Math.round(signalBarRaw)))
      : undefined;
    const rssi = payload.rssi != null && String(payload.rssi).trim() !== '' ? `${payload.rssi} dBm` : undefined;
    const rsrp = payload.lte_rsrp != null && String(payload.lte_rsrp).trim() !== '' ? `${payload.lte_rsrp} dBm` : undefined;
    const wanIp = String(payload.wan_ipaddr || payload.ppp_ipaddr || '').trim() || undefined;
    const hardwareVersion = String(payload.hardware_version || payload.wa_inner_version || '').trim() || undefined;
    const firmwareVersion = String(payload.cr_version || payload.wa_inner_version || '').trim() || undefined;

    return {
      ssid24,
      ssid5,
      networkProvider,
      networkType,
      signalBar,
      rssi,
      rsrp,
      wanIp,
      hardwareVersion,
      firmwareVersion,
    };
  }

  /**
   * Direct 3-step live connection test via CapacitorHttp:
   * 1. Reach Router Gateway (/login.html or /index.html) -> 2. Authenticate Admin Session -> 3. Read Connected Clients & Signal Info.
   */
  async testConnection(config: RouterConfig): Promise<RouterTestResult> {
    if (config.mode === 'demo') {
      await this.delay(180);
      return {
        ok: true,
        isDemo: true,
        message: 'Demo mode ready',
        networkInfo: {
          ssid24: this.demoSsid,
          ssid5: config.ssid5,
          networkProvider: 'Airtel TZ (Demo)',
          networkType: '4G LTE',
          signalBar: 4,
          rssi: '-64 dBm',
          wanIp: '105.231.42.18',
          hardwareVersion: 'ZLT S10G',
        },
      };
    }

    const steps: DiagnosticStep[] = [];

    if (!isValidGatewayHost(config.gatewayIp)) {
      return {
        ok: false,
        isDemo: false,
        reason: 'invalid_host',
        message: 'Invalid private LAN gateway IP address',
      };
    }

    if (this.isBrowserHttpsBlocked()) {
      return {
        ok: false,
        isDemo: false,
        reason: 'mixed_content',
        message: 'Direct HTTP to router LAN requires Android APK (Capacitor) or local HTTP.',
      };
    }

    // Step 1: Reach Router Gateway (probe /login.html first for Airtel TZ Tozed/ZLT, then /index.html)
    const gateway = cleanGatewayHost(config.gatewayIp);
    let gatewayReached = false;
    let reachedStatus = 0;
    let reachedPath = '/login.html';

    for (const probePath of ['/login.html', '/index.html']) {
      try {
        const probeRes = await this.sendRouterRequest(config, probePath, {
          method: 'GET',
          timeoutMs: 3000,
          refererPath: probePath,
        });
        if (probeRes.status > 0 && probeRes.status < 500) {
          gatewayReached = true;
          reachedStatus = probeRes.status;
          reachedPath = probePath;
          if (probeRes.status < 400) {
            this.loginRefererByGateway.set(gateway, probePath);
            break;
          }
        }
      } catch {
        // try next probe path
      }
    }

    if (!gatewayReached) {
      steps.push({
        id: 'gateway',
        label: `Router ${gateway}`,
        status: 'fail',
        detail: 'No response on LAN',
      });
      return {
        ok: false,
        isDemo: false,
        reason: 'gateway_unreachable',
        message: `Router ${gateway} unreachable`,
        steps,
      };
    }

    steps.push({
      id: 'gateway',
      label: `Router ${gateway}`,
      status: 'ok',
      detail: `${reachedPath} · HTTP ${reachedStatus}`,
    });

    // Step 2: Force Fresh Admin Login & Capture Session Cookie / stok
    this.clearGatewaySession(gateway);
    const auth = await this.ensureAuthenticated(config);
    if (!auth.ok) {
      steps.push({
        id: 'login',
        label: 'Router Admin Login',
        status: 'fail',
        detail: auth.authRejected
          ? 'Wrong username or password'
          : 'Router API login endpoint not accepted',
      });
      return {
        ok: false,
        isDemo: false,
        reason: auth.authRejected ? 'auth_failed' : 'network_error',
        message: auth.authRejected ? 'Wrong router admin password' : 'Router API login failed',
        steps,
      };
    }

    steps.push({
      id: 'login',
      label: 'Router Admin Login',
      status: 'ok',
      detail: auth.variantLabel || auth.protocol,
    });

    // Step 3: Fetch Connected Clients & Signal / Network Info using captured Cookie/stok
    let clientCount = 0;
    let networkInfo: RouterNetworkInfo | undefined;
    try {
      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'station_list,dhcp_list,lan_station_list,SSID1,m_SSID1,network_provider,network_type,signalbar,rssi,lte_rsrp,wan_ipaddr,hardware_version'
      );
      if (payload) {
        clientCount = this.parseZltStationPayload(payload).length;
        networkInfo = this.parseNetworkInfo(payload, config.ssid24);
      }
      steps.push({
        id: 'clients',
        label: 'Clients & Network Info',
        status: 'ok',
        detail: `${clientCount} clients`,
      });
    } catch {
      steps.push({
        id: 'clients',
        label: 'Clients & Network Info',
        status: 'fail',
        detail: 'Could not read station_list',
      });
    }

    return {
      ok: true,
      isDemo: false,
      message: 'Connected',
      detectedSsid: networkInfo?.ssid24,
      detectedProtocol: auth.protocol,
      detectedVariantLabel: auth.variantLabel,
      clientCount,
      networkInfo,
      steps,
    };
  }

  /**
   * Reads live connected Wi-Fi & LAN devices directly from the router using captured Cookie/stok.
   */
  async getConnectedDevices(
    config: RouterConfig
  ): Promise<{ devices: ConnectedDevice[]; connectedLive: boolean; fallbackUsed: boolean }> {
    if (config.mode === 'demo') {
      await this.delay(150);
      return { devices: [...this.demoDevices], connectedLive: false, fallbackUsed: false };
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return { devices: [], connectedLive: false, fallbackUsed: true };
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) {
        return { devices: [], connectedLive: false, fallbackUsed: true };
      }

      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'station_list,dhcp_list,lan_station_list'
      );
      if (!payload) {
        return { devices: [], connectedLive: false, fallbackUsed: true };
      }
      const parsed = this.parseZltStationPayload(payload);
      return { devices: parsed, connectedLive: true, fallbackUsed: false };
    } catch {
      return { devices: [], connectedLive: false, fallbackUsed: true };
    }
  }

  /**
   * Fetches live cellular signal, operator, WAN IP, and Wi-Fi SSID directly from the router.
   */
  async getRouterNetworkInfo(config: RouterConfig): Promise<RouterNetworkInfo | null> {
    if (config.mode === 'demo') {
      await this.delay(140);
      return {
        ssid24: this.demoSsid,
        ssid5: config.ssid5,
        networkProvider: 'Airtel TZ (Demo)',
        networkType: '4G LTE',
        signalBar: 4,
        rssi: '-64 dBm',
        rsrp: '-88 dBm',
        wanIp: '105.231.42.18',
        hardwareVersion: 'ZLT S10G',
      };
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return null;
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return null;
      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'SSID1,SSID2,m_SSID1,network_provider,network_type,signalbar,rssi,lte_rsrp,wan_ipaddr,hardware_version,wa_inner_version'
      );
      if (!payload) return null;
      return this.parseNetworkInfo(payload, config.ssid24);
    } catch {
      return null;
    }
  }

  /**
   * Updates Wi-Fi SSID & WPA2 password directly on the connected ZLT/Tozed router.
   */
  async updateWifiSettings(
    config: RouterConfig,
    params: { ssid: string; wifiPassword: string }
  ): Promise<{ ok: boolean; error?: string }> {
    const cleanSsid = params.ssid.trim();
    const cleanPass = params.wifiPassword;
    if (!cleanSsid || cleanSsid.length > 32) {
      return { ok: false, error: 'SSID must be 1-32 characters' };
    }
    if (cleanPass && (cleanPass.length < 8 || cleanPass.length > 63)) {
      return { ok: false, error: 'Wi-Fi password must be 8-63 characters' };
    }

    if (config.mode === 'demo') {
      await this.delay(180);
      this.demoSsid = cleanSsid;
      return { ok: true };
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return { ok: false, error: 'Router unreachable' };
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return { ok: false, error: 'Router login required' };

      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      if (auth.protocol === 'tozed_web' && submode === 'api_login') {
        const res = await this.sendRouterRequest(config, '/api/wifi', {
          method: 'POST',
          contentType: 'application/json; charset=UTF-8',
          body: JSON.stringify({
            ssid: cleanSsid,
            ...(cleanPass ? { password: cleanPass } : {}),
          }),
        });
        return { ok: res.ok };
      }

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const body = new URLSearchParams({
        isTest: 'false',
        goformId: 'SET_WIFI_INFO',
        m_ssid: cleanSsid,
        SSID1: cleanSsid,
        ...(cleanPass
          ? {
              passphrase: cleanPass,
              WPAPSK1: cleanPass,
              AuthMode: 'WPA2PSK',
              EncrypType: 'AES',
            }
          : {}),
      }).toString();

      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body,
      });
      return { ok: res.ok };
    } catch {
      return { ok: false, error: 'Failed to update Wi-Fi settings' };
    }
  }

  /**
   * Reboots the connected ZLT/Tozed CPE router directly.
   */
  async rebootRouter(config: RouterConfig): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(220);
      return true;
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return false;
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return false;

      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      if (auth.protocol === 'tozed_web' && submode === 'api_login') {
        const res = await this.sendRouterRequest(config, '/api/reboot', {
          method: 'POST',
          contentType: 'application/json; charset=UTF-8',
          body: JSON.stringify({ action: 'reboot' }),
        });
        return res.ok;
      }

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'REBOOT_DEVICE',
        }).toString(),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  /**
   * Imports existing MAC filter mode and MAC rules directly from the router.
   */
  async fetchRouterFirewallState(
    config: RouterConfig
  ): Promise<{ ok: boolean; mode?: FirewallFilterMode; macs?: string[] }> {
    if (config.mode !== 'router' || !isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return { ok: false };
    }
    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return { ok: false };

      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'mac_filter_mode,mac_filter_list'
      );
      if (!payload) return { ok: false };

      const rawMode = String(payload.mac_filter_mode ?? '0');
      const mode: FirewallFilterMode =
        rawMode === '1' ? 'whitelist' : rawMode === '2' ? 'blacklist' : 'disabled';

      const macs: string[] = [];
      const rawList = payload.mac_filter_list;
      if (Array.isArray(rawList)) {
        for (const item of rawList) {
          const mac =
            typeof item === 'string'
              ? item
              : String((item as Record<string, unknown>)?.mac ?? '');
          if (mac.includes(':')) macs.push(mac.trim().toUpperCase());
        }
      } else if (typeof rawList === 'string' && rawList.trim()) {
        for (const token of rawList.split(/[;,]/)) {
          const cleaned = token.trim().toUpperCase();
          if (/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(cleaned)) {
            macs.push(cleaned);
          }
        }
      }

      return { ok: true, mode, macs };
    } catch {
      return { ok: false };
    }
  }

  simulateClientConnect(): ConnectedDevice {
    const candidate = SIMULATED_POOL[this.poolIndex % SIMULATED_POOL.length];
    this.poolIndex += 1;

    const existing = this.demoDevices.find((d) => d.macAddress === candidate.macAddress);
    if (existing) {
      const randomHex = () =>
        Math.floor(Math.random() * 256)
          .toString(16)
          .padStart(2, '0')
          .toUpperCase();
      const customDevice: ConnectedDevice = {
        id: `dev-sim-${Date.now()}`,
        hostname: `Android-Client-${Math.floor(100 + Math.random() * 899)}`,
        ipAddress: `192.168.1.${140 + (this.demoDevices.length % 90)}`,
        macAddress: `${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}`,
        connectionType: Math.random() > 0.4 ? '2.4GHz' : '5GHz',
        online: true,
        signalStrength: -54 - Math.floor(Math.random() * 18),
        connectedSince: Date.now(),
      };
      this.demoDevices = [customDevice, ...this.demoDevices];
      return customDevice;
    }

    const newDevice: ConnectedDevice = {
      id: `dev-sim-${Date.now()}`,
      hostname: candidate.hostname,
      ipAddress: `192.168.1.${130 + this.demoDevices.length}`,
      macAddress: candidate.macAddress,
      connectionType: candidate.connectionType,
      online: true,
      signalStrength: candidate.connectionType === 'LAN' ? undefined : -55,
      connectedSince: Date.now(),
    };
    this.demoDevices = [newDevice, ...this.demoDevices];
    return newDevice;
  }

  async setMacFilterMode(config: RouterConfig, mode: FirewallFilterMode): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(100);
      return true;
    }
    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) return false;

    const routerModeCode = mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0';
    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return false;
      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'SET_MAC_FILTER_MODE',
          mac_filter_mode: routerModeCode,
        }).toString(),
      });
      if (res.ok) return true;

      // Boa firmware fallback when authenticated via /boafrm/formLogin
      if (submode === 'boafrm') {
        const boaRes = await this.sendRouterRequest(config, '/boafrm/formMacFilter', {
          method: 'POST',
          body: new URLSearchParams({
            enabled: mode === 'disabled' ? '0' : '1',
            filterMode: routerModeCode,
          }).toString(),
        });
        return boaRes.ok;
      }

      return false;
    } catch {
      return false;
    }
  }

  async syncFirewallRules(
    config: RouterConfig,
    mode: FirewallFilterMode,
    rules: FirewallRule[]
  ): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(100);
      return true;
    }
    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) return false;

    const effectiveMacs =
      mode === 'whitelist'
        ? rules.filter((r) => r.enabled && !r.expired).map((r) => r.macAddress)
        : mode === 'blacklist'
          ? rules.filter((r) => r.enabled || r.expired).map((r) => r.macAddress)
          : [];

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return false;
      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'SET_MAC_FILTER',
          mac_filter_mode: mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0',
          mac_filter_enable: mode === 'disabled' ? '0' : '1',
          mac_filter_list: effectiveMacs.join(';'),
        }).toString(),
      });
      if (res.ok) return true;

      // Boa firmware fallback when authenticated via /boafrm/formLogin
      if (submode === 'boafrm') {
        const boaRes = await this.sendRouterRequest(config, '/boafrm/formMacFilter', {
          method: 'POST',
          body: new URLSearchParams({
            enabled: mode === 'disabled' ? '0' : '1',
            filterMode: mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0',
            macList: effectiveMacs.join(';'),
          }).toString(),
        });
        return boaRes.ok;
      }

      return false;
    } catch {
      return false;
    }
  }

  private parseZltStationPayload(payload: Record<string, unknown>): ConnectedDevice[] {
    const seenMacs = new Map<string, ConnectedDevice>();

    const addEntry = (
      macRaw: unknown,
      hostnameRaw: unknown,
      ipRaw: unknown,
      bandRaw: unknown
    ) => {
      const mac = String(macRaw || '').trim().toUpperCase().replace(/-/g, ':');
      if (!/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(mac)) return;
      if (seenMacs.has(mac)) return;

      const bandStr = String(bandRaw || '2.4GHz').toLowerCase();
      const connectionType: ConnectionBand =
        bandStr.includes('5g') || bandStr.includes('5.8') || bandStr === '5'
          ? '5GHz'
          : bandStr.includes('lan') || bandStr.includes('eth') || bandStr.includes('wired')
            ? 'LAN'
            : '2.4GHz';

      const hostname =
        String(hostnameRaw || '').trim() || `Client-${mac.slice(-5).replace(':', '')}`;
      const ipAddress = String(ipRaw || '').trim() || '192.168.1.x';

      seenMacs.set(mac, {
        id: `cpe-${mac}`,
        hostname,
        ipAddress,
        macAddress: mac,
        connectionType,
        online: true,
        connectedSince: Date.now(),
      });
    };

    const parseCollection = (raw: unknown, defaultBand: ConnectionBand) => {
      if (Array.isArray(raw)) {
        for (const item of raw) {
          if (item && typeof item === 'object') {
            const rec = item as Record<string, unknown>;
            addEntry(
              rec.mac_addr ?? rec.mac ?? rec.macAddress ?? rec.sta_mac ?? rec.macaddr,
              rec.hostname ?? rec.dev_name ?? rec.host_name ?? rec.name ?? rec.device_name,
              rec.ip_addr ?? rec.ip ?? rec.ipAddress ?? rec.sta_ip ?? rec.ipaddr,
              rec.connect_type ?? rec.wifi_mode ?? rec.band ?? rec.interface ?? defaultBand
            );
          } else if (typeof item === 'string') {
            const parts = item.split(',').map((s) => s.trim());
            const mac = parts.find((p) => /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(p));
            const ip = parts.find((p) => /^\d{1,3}(\.\d{1,3}){3}$/.test(p));
            const host = parts.find((p) => p !== mac && p !== ip && p.length > 0);
            if (mac) addEntry(mac, host, ip, defaultBand);
          }
        }
      } else if (typeof raw === 'string' && raw.trim()) {
        for (const row of raw.split(';')) {
          const parts = row.split(',').map((s) => s.trim());
          const mac = parts.find((p) => /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(p));
          const ip = parts.find((p) => /^\d{1,3}(\.\d{1,3}){3}$/.test(p));
          const host = parts.find((p) => p !== mac && p !== ip && p.length > 0);
          if (mac) addEntry(mac, host, ip, defaultBand);
        }
      }
    };

    parseCollection(payload.station_list, '2.4GHz');
    parseCollection(payload.lan_station_list, 'LAN');
    parseCollection(payload.dhcp_list, '2.4GHz');
    parseCollection(payload.dhcp_client_list, '2.4GHz');
    parseCollection(payload.leases, '2.4GHz');
    parseCollection(payload.clients, '2.4GHz');
    parseCollection(payload.data, '2.4GHz');

    return Array.from(seenMacs.values());
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
}

export const routerApiService = new RouterApiService();
