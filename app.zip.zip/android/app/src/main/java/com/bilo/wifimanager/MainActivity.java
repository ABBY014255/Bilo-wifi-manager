package com.bilo.wifimanager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
