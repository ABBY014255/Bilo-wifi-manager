import {
  ConnectionBand,
  ConnectedDevice,
  FirewallFilterMode,
  FirewallRule,
  RouterConfig,
  RouterTestResult,
} from '../types';

/**
 * RouterApiService
 * Full ZLT / Tozed (TZLink) CPE Router integration layer supporting:
 * 1. Local Wi-Fi Bridge (http://127.0.0.1:8787) — bypasses browser CORS & HTTPS Mixed Content
 *    when using the hosted web app while connected to a real Wi-Fi router.
 * 2. Direct LAN HTTP/HTTPS — connects directly to the router IP (ideal when running locally
 *    over HTTP, inside an Android WebView/APK, or via an HTTPS tunnel).
 * 3. Built-in Demo/Simulation Mode when no physical router is attached.
 */

const INITIAL_DEMO_DEVICES: ConnectedDevice[] = [
  {
    id: 'dev-1',
    hostname: 'iPhone-14-Pro',
    ipAddress: '192.168.0.101',
    macAddress: 'A4:83:E7:2B:91:0C',
    connectionType: '5GHz',
    online: true,
    signalStrength: -48,
    connectedSince: Date.now() - 4 * 60 * 60 * 1000,
  },
  {
    id: 'dev-2',
    hostname: 'Galaxy-A15-Juma',
    ipAddress: '192.168.0.104',
    macAddress: '7C:2A:31:F4:88:12',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -61,
    connectedSince: Date.now() - 3 * 60 * 60 * 1000,
  },
  {
    id: 'dev-3',
    hostname: 'TECNO-SPARK-20',
    ipAddress: '192.168.0.108',
    macAddress: 'B8:53:AC:60:4D:71',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -57,
    connectedSince: Date.now() - 58 * 60 * 1000,
  },
  {
    id: 'dev-4',
    hostname: 'LG-WebOS-SmartTV',
    ipAddress: '192.168.0.112',
    macAddress: 'CC:2D:83:41:5E:19',
    connectionType: 'LAN',
    online: true,
    connectedSince: Date.now() - 18 * 60 * 60 * 1000,
  },
  {
    id: 'dev-5',
    hostname: 'HP-Pavilion-Baraka',
    ipAddress: '192.168.0.115',
    macAddress: 'D8:F2:CA:19:03:AF',
    connectionType: '5GHz',
    online: true,
    signalStrength: -52,
    connectedSince: Date.now() - 2 * 60 * 60 * 1000,
  },
  {
    id: 'dev-6',
    hostname: 'Redmi-13C-Guest',
    ipAddress: '192.168.0.121',
    macAddress: '50:8E:49:9D:33:E4',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -66,
    connectedSince: Date.now() - 19 * 60 * 1000,
  },
  {
    id: 'dev-7',
    hostname: 'Infinix-HOT-40i',
    ipAddress: '192.168.0.129',
    macAddress: '24:4B:FE:A1:77:05',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -64,
    connectedSince: Date.now() - 11 * 60 * 1000,
  },
];

const SIMULATED_POOL: Array<{ hostname: string; macAddress: string; connectionType: ConnectionBand }> = [
  { hostname: 'Samsung-Galaxy-A05', macAddress: '8C:F5:A3:44:21:9E', connectionType: '2.4GHz' },
  { hostname: 'iPhone-12-Mini', macAddress: 'F0:18:98:7C:55:B2', connectionType: '5GHz' },
  { hostname: 'TECNO-CAMON-30', macAddress: '64:A2:F9:1E:08:D3', connectionType: '5GHz' },
  { hostname: 'Lenovo-ThinkPad-T14', macAddress: '00:1A:79:B2:46:81', connectionType: 'LAN' },
  { hostname: 'OPPO-A38-Client', macAddress: 'AC:37:43:D9:14:6B', connectionType: '2.4GHz' },
];

const IPV4_OR_HOST_RE = /^[a-zA-Z0-9.-]+(:\d{1,5})?$/;

export function isValidGatewayHost(raw: string): boolean {
  const cleaned = raw.trim().replace(/^https?:\/\//, '').replace(/\/+$/, '');
  return cleaned.length > 0 && cleaned.length <= 253 && IPV4_OR_HOST_RE.test(cleaned);
}

export function isValidBridgeUrl(raw: string): boolean {
  try {
    const parsed = new URL(raw.trim());
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    // Allow loopback bridge on http, or any https custom bridge
    if (parsed.protocol === 'http:') {
      return parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost';
    }
    return true;
  } catch {
    return false;
  }
}

class RouterApiService {
  private demoDevices: ConnectedDevice[] = [...INITIAL_DEMO_DEVICES];
  private poolIndex = 0;

  private getDirectBaseUrl(config: RouterConfig): string {
    const raw = config.gatewayIp.trim().replace(/\/+$/, '');
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return raw;
    }
    return `http://${raw}`;
  }

  private getBridgeBaseUrl(config: RouterConfig): string {
    return config.bridgeUrl.trim().replace(/\/+$/, '');
  }

  private isMixedContentBlocked(config: RouterConfig): boolean {
    if (config.mode !== 'router' || config.transport !== 'direct') return false;
    const isPageHttps = typeof window !== 'undefined' && window.location.protocol === 'https:';
    const targetUrl = this.getDirectBaseUrl(config);
    return isPageHttps && targetUrl.startsWith('http://');
  }

  /**
   * Low-level request dispatcher that routes ZLT/Tozed `/goform/*` calls
   * either through the Local Wi-Fi Bridge or directly to the CPE gateway.
   */
  private async sendRouterRequest(
    config: RouterConfig,
    goformPath: string,
    options: { method: 'GET' | 'POST'; body?: URLSearchParams; timeoutMs?: number }
  ): Promise<Response> {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), options.timeoutMs ?? 5000);

    try {
      if (config.transport === 'bridge') {
        const bridgeBase = this.getBridgeBaseUrl(config);
        const gateway = config.gatewayIp.trim().replace(/^https?:\/\//, '').replace(/\/+$/, '');
        const url = `${bridgeBase}/api/zlt${goformPath}`;
        const res = await fetch(url, {
          method: options.method,
          headers: {
            'X-Router-Gateway': gateway,
            ...(options.method === 'POST'
              ? { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
              : {}),
          },
          body: options.body ? options.body.toString() : undefined,
          signal: controller.signal,
        });
        window.clearTimeout(timeout);
        return res;
      }

      const directBase = this.getDirectBaseUrl(config);
      const res = await fetch(`${directBase}${goformPath}`, {
        method: options.method,
        credentials: 'include',
        headers:
          options.method === 'POST'
            ? { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
            : undefined,
        body: options.body ? options.body.toString() : undefined,
        signal: controller.signal,
      });
      window.clearTimeout(timeout);
      return res;
    } catch (err) {
      window.clearTimeout(timeout);
      throw err;
    }
  }

  /**
   * Authenticates with a ZLT/Tozed CPE router (`goformId=LOGIN`) and verifies
   * we can read real connected devices + SSID.
   */
  async testConnection(config: RouterConfig): Promise<RouterTestResult> {
    if (config.mode === 'demo') {
      await this.delay(220);
      return { ok: true, isDemo: true, message: 'Demo mode ready' };
    }

    if (!isValidGatewayHost(config.gatewayIp)) {
      return {
        ok: false,
        isDemo: false,
        reason: 'invalid_host',
        message: 'Invalid gateway IP address',
      };
    }

    if (config.transport === 'bridge' && !isValidBridgeUrl(config.bridgeUrl)) {
      return {
        ok: false,
        isDemo: false,
        reason: 'bridge_offline',
        message: 'Invalid Local Bridge URL',
      };
    }

    if (this.isMixedContentBlocked(config)) {
      return {
        ok: false,
        isDemo: false,
        reason: 'mixed_content',
        message: 'HTTPS browser blocks direct HTTP calls to local IP. Use Local Wi-Fi Bridge.',
      };
    }

    try {
      // 1. If using Local Bridge, first verify bridge health so we give an exact diagnosis
      if (config.transport === 'bridge') {
        const healthCtrl = new AbortController();
        const healthTimeout = window.setTimeout(() => healthCtrl.abort(), 2500);
        try {
          const healthRes = await fetch(`${this.getBridgeBaseUrl(config)}/api/health`, {
            signal: healthCtrl.signal,
          });
          window.clearTimeout(healthTimeout);
          if (!healthRes.ok) {
            return {
              ok: false,
              isDemo: false,
              reason: 'bridge_offline',
              message: 'Local Wi-Fi Bridge responded with error',
            };
          }
        } catch {
          window.clearTimeout(healthTimeout);
          return {
            ok: false,
            isDemo: false,
            reason: 'bridge_offline',
            message: 'Local Wi-Fi Bridge is not running on this device',
          };
        }
      }

      // 2. Authenticate with ZLT/Tozed CPE router (Base64 password)
      const encodedPassword = btoa(config.password || 'admin');
      const loginBody = new URLSearchParams({
        isTest: 'false',
        goformId: 'LOGIN',
        username: config.username || 'admin',
        password: encodedPassword,
      });

      const loginRes = await this.sendRouterRequest(config, '/goform/goform_set_cmd_process', {
        method: 'POST',
        body: loginBody,
      });

      if (!loginRes.ok) {
        return {
          ok: false,
          isDemo: false,
          reason: 'network_error',
          message: `HTTP ${loginRes.status}`,
        };
      }

      const loginData = (await loginRes.json().catch(() => ({}))) as Record<string, unknown>;
      const resultVal = String(loginData.result ?? '0').toLowerCase();
      if (resultVal === '3' || resultVal === 'failure' || resultVal === 'error') {
        return {
          ok: false,
          isDemo: false,
          reason: 'auth_failed',
          message: 'Wrong router admin password',
        };
      }

      // 3. Query real clients & SSID to confirm full read access
      const infoRes = await this.sendRouterRequest(
        config,
        '/goform/goform_get_cmd_process?isTest=false&cmd=station_list,lan_station_list,dhcp_client_list,SSID1,m_SSID1&multi_data=1',
        { method: 'GET' }
      );

      let clientCount = 0;
      let detectedSsid: string | undefined;
      if (infoRes.ok) {
        const payload = (await infoRes.json().catch(() => ({}))) as Record<string, unknown>;
        clientCount = this.parseZltStationPayload(payload).length;
        const ssid = String(payload.SSID1 || payload.m_SSID1 || '').trim();
        if (ssid) detectedSsid = ssid;
      }

      return {
        ok: true,
        isDemo: false,
        message: 'Connected',
        detectedSsid,
        clientCount,
      };
    } catch (err) {
      return {
        ok: false,
        isDemo: false,
        reason: config.transport === 'bridge' ? 'network_error' : 'network_error',
        message: err instanceof Error ? err.message : 'Unreachable',
      };
    }
  }

  /**
   * Reads connected Wi-Fi & LAN station list from ZLT/Tozed CPE router.
   */
  async getConnectedDevices(
    config: RouterConfig
  ): Promise<{ devices: ConnectedDevice[]; connectedLive: boolean; fallbackUsed: boolean }> {
    if (config.mode === 'demo') {
      await this.delay(160);
      return { devices: [...this.demoDevices], connectedLive: false, fallbackUsed: false };
    }

    if (this.isMixedContentBlocked(config)) {
      return { devices: [], connectedLive: false, fallbackUsed: true };
    }

    try {
      const res = await this.sendRouterRequest(
        config,
        '/goform/goform_get_cmd_process?isTest=false&cmd=station_list,lan_station_list,dhcp_client_list&multi_data=1',
        { method: 'GET' }
      );

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = (await res.json()) as Record<string, unknown>;
      const parsed = this.parseZltStationPayload(payload);
      return { devices: parsed, connectedLive: true, fallbackUsed: false };
    } catch {
      return { devices: [], connectedLive: false, fallbackUsed: true };
    }
  }

  /**
   * Reads existing MAC filter mode and MAC list from a live ZLT/Tozed router
   * so the user can import existing router rules into Bilo wifi manager Pro.
   */
  async fetchRouterFirewallState(
    config: RouterConfig
  ): Promise<{ ok: boolean; mode?: FirewallFilterMode; macs?: string[] }> {
    if (config.mode !== 'router' || this.isMixedContentBlocked(config)) {
      return { ok: false };
    }
    try {
      const res = await this.sendRouterRequest(
        config,
        '/goform/goform_get_cmd_process?isTest=false&cmd=mac_filter_mode,mac_filter_list&multi_data=1',
        { method: 'GET' }
      );
      if (!res.ok) return { ok: false };
      const payload = (await res.json()) as Record<string, unknown>;
      const rawMode = String(payload.mac_filter_mode ?? '0');
      const mode: FirewallFilterMode =
        rawMode === '1' ? 'whitelist' : rawMode === '2' ? 'blacklist' : 'disabled';

      const macs: string[] = [];
      const rawList = payload.mac_filter_list;
      if (Array.isArray(rawList)) {
        for (const item of rawList) {
          const mac = typeof item === 'string' ? item : String((item as Record<string, unknown>)?.mac ?? '');
          if (mac.includes(':')) macs.push(mac.trim().toUpperCase());
        }
      } else if (typeof rawList === 'string' && rawList.trim()) {
        for (const token of rawList.split(/[;,]/)) {
          const cleaned = token.trim().toUpperCase();
          if (/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(cleaned)) {
            macs.push(cleaned);
          }
        }
      }

      return { ok: true, mode, macs };
    } catch {
      return { ok: false };
    }
  }

  /**
   * Simulates a new Wi-Fi client connecting in Demo Mode.
   */
  simulateClientConnect(): ConnectedDevice {
    const candidate = SIMULATED_POOL[this.poolIndex % SIMULATED_POOL.length];
    this.poolIndex += 1;

    const existing = this.demoDevices.find((d) => d.macAddress === candidate.macAddress);
    if (existing) {
      const randomHex = () =>
        Math.floor(Math.random() * 256)
          .toString(16)
          .padStart(2, '0')
          .toUpperCase();
      const customDevice: ConnectedDevice = {
        id: `dev-sim-${Date.now()}`,
        hostname: `Android-Client-${Math.floor(100 + Math.random() * 899)}`,
        ipAddress: `192.168.0.${140 + (this.demoDevices.length % 90)}`,
        macAddress: `${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}:${randomHex()}`,
        connectionType: Math.random() > 0.4 ? '2.4GHz' : '5GHz',
        online: true,
        signalStrength: -54 - Math.floor(Math.random() * 18),
        connectedSince: Date.now(),
      };
      this.demoDevices = [customDevice, ...this.demoDevices];
      return customDevice;
    }

    const newDevice: ConnectedDevice = {
      id: `dev-sim-${Date.now()}`,
      hostname: candidate.hostname,
      ipAddress: `192.168.0.${130 + this.demoDevices.length}`,
      macAddress: candidate.macAddress,
      connectionType: candidate.connectionType,
      online: true,
      signalStrength: candidate.connectionType === 'LAN' ? undefined : -55,
      connectedSince: Date.now(),
    };
    this.demoDevices = [newDevice, ...this.demoDevices];
    return newDevice;
  }

  /**
   * Syncs MAC filter mode (Whitelist / Blacklist / Disabled) to ZLT/Tozed router.
   */
  async setMacFilterMode(config: RouterConfig, mode: FirewallFilterMode): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(100);
      return true;
    }
    if (this.isMixedContentBlocked(config)) return false;

    const routerModeCode = mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0';
    try {
      const res = await this.sendRouterRequest(config, '/goform/goform_set_cmd_process', {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'SET_MAC_FILTER_MODE',
          mac_filter_mode: routerModeCode,
        }),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  /**
   * Pushes updated MAC filter table to ZLT/Tozed router whenever a rule is added,
   * toggled, deleted, renewed, or auto-expired.
   */
  async syncFirewallRules(
    config: RouterConfig,
    mode: FirewallFilterMode,
    rules: FirewallRule[]
  ): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(100);
      return true;
    }
    if (this.isMixedContentBlocked(config)) return false;

    const effectiveMacs =
      mode === 'whitelist'
        ? rules.filter((r) => r.enabled && !r.expired).map((r) => r.macAddress)
        : mode === 'blacklist'
          ? rules.filter((r) => r.enabled || r.expired).map((r) => r.macAddress)
          : [];

    try {
      const res = await this.sendRouterRequest(config, '/goform/goform_set_cmd_process', {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'SET_MAC_FILTER',
          mac_filter_mode: mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0',
          mac_filter_enable: mode === 'disabled' ? '0' : '1',
          mac_filter_list: effectiveMacs.join(';'),
        }),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  /**
   * Generates a clean, zero-dependency Node.js Local Wi-Fi Bridge (`bilo-router-bridge.mjs`)
   * that runs on the user's PC or Android Termux on the same Wi-Fi LAN as their ZLT/Tozed router.
   * Binds strictly to 127.0.0.1, manages CPE session cookies, injects required Referer headers,
   * and only forwards `/goform/*` requests to the validated router gateway IP.
   */
  generateLocalBridgeScript(defaultGatewayIp: string, appOrigin: string): string {
    const safeGateway = isValidGatewayHost(defaultGatewayIp) ? defaultGatewayIp.trim() : '192.168.0.1';
    const safeOrigin = appOrigin || 'http://localhost:3000';

    return `#!/usr/bin/env node
/**
 * Bilo wifi manager Pro — Local Wi-Fi Router Bridge
 * Run on a computer or Android (Termux) connected to your ZLT / Tozed Wi-Fi router:
 *   node bilo-router-bridge.mjs
 *
 * Security:
 * - Listens ONLY on 127.0.0.1:8787 (local loopback)
 * - Forwards ONLY /goform/* CPE router endpoints to private LAN gateway IPs
 * - Holds router session cookies strictly in memory (never written to disk)
 */

import http from 'node:http';

const PORT = Number(process.env.BILO_BRIDGE_PORT || 8787);
const DEFAULT_GATEWAY = ${JSON.stringify(safeGateway)};
const ALLOWED_ORIGINS = new Set([
  ${JSON.stringify(safeOrigin)},
  'http://localhost:3000',
  'http://127.0.0.1:3000',
]);

// Strictly allow private LAN IPv4 router gateways only
const PRIVATE_LAN_IP_RE = /^(192\\.168\\.\\d{1,3}\\.\\d{1,3}|10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.(1[6-9]|2\\d|3[0-1])\\.\\d{1,3}\\.\\d{1,3})(:\\d{1,5})?$/;

const cookieJar = new Map();

function corsHeaders(origin) {
  const allow = origin && ALLOWED_ORIGINS.has(origin) ? origin : ${JSON.stringify(safeOrigin)};
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Router-Gateway',
    'Vary': 'Origin',
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 65536) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || '';
  const headers = corsHeaders(origin);

  if (req.method === 'OPTIONS') {
    res.writeHead(204, headers);
    res.end();
    return;
  }

  if (req.url === '/api/health') {
    res.writeHead(200, { ...headers, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, bridge: 'bilo-wifi-manager-pro', defaultGateway: DEFAULT_GATEWAY }));
    return;
  }

  if (!req.url || !req.url.startsWith('/api/zlt/goform/')) {
    res.writeHead(404, { ...headers, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));
    return;
  }

  const rawGateway = String(req.headers['x-router-gateway'] || DEFAULT_GATEWAY).trim();
  if (!PRIVATE_LAN_IP_RE.test(rawGateway)) {
    res.writeHead(400, { ...headers, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Only private LAN router IP addresses are permitted.' }));
    return;
  }

  const routerPath = req.url.slice('/api/zlt'.length);
  const targetUrl = \`http://\${rawGateway}\${routerPath}\`;

  try {
    const body = req.method === 'POST' ? await readBody(req) : undefined;
    const savedCookie = cookieJar.get(rawGateway);

    const upstream = await fetch(targetUrl, {
      method: req.method,
      headers: {
        'Referer': \`http://\${rawGateway}/index.html\`,
        'Origin': \`http://\${rawGateway}\`,
        ...(body !== undefined ? { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' } : {}),
        ...(savedCookie ? { 'Cookie': savedCookie } : {}),
      },
      body,
    });

    const setCookies = upstream.headers.getSetCookie ? upstream.headers.getSetCookie() : [];
    if (setCookies.length > 0) {
      const merged = setCookies.map((c) => c.split(';')[0]).join('; ');
      cookieJar.set(rawGateway, merged);
    }

    const text = await upstream.text();
    res.writeHead(upstream.status, {
      ...headers,
      'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
    });
    res.end(text);
  } catch (err) {
    res.writeHead(502, { ...headers, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Router unreachable', detail: err instanceof Error ? err.message : String(err) }));
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(\`[Bilo wifi manager Pro] Local Wi-Fi Bridge listening on http://127.0.0.1:\${PORT}\`);
  console.log(\`Ready to connect to your ZLT / Tozed router at http://\${DEFAULT_GATEWAY}\`);
});
`;
  }

  /**
   * Parses connected devices from multiple ZLT/Tozed CPE firmware payload shapes:
   * - station_list (array of objects OR delimited strings)
   * - lan_station_list (array of objects)
   * - dhcp_client_list (fallback DHCP leases)
   */
  private parseZltStationPayload(payload: Record<string, unknown>): ConnectedDevice[] {
    const seenMacs = new Map<string, ConnectedDevice>();

    const addEntry = (
      macRaw: unknown,
      hostnameRaw: unknown,
      ipRaw: unknown,
      bandRaw: unknown
    ) => {
      const mac = String(macRaw || '').trim().toUpperCase();
      if (!/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(mac)) return;
      if (seenMacs.has(mac)) return;

      const bandStr = String(bandRaw || '2.4GHz').toLowerCase();
      const connectionType: ConnectionBand =
        bandStr.includes('5g') || bandStr.includes('5.8') || bandStr === '5'
          ? '5GHz'
          : bandStr.includes('lan') || bandStr.includes('eth') || bandStr.includes('wired')
            ? 'LAN'
            : '2.4GHz';

      const hostname = String(hostnameRaw || '').trim() || `Client-${mac.slice(-5).replace(':', '')}`;
      const ipAddress = String(ipRaw || '').trim() || '192.168.0.x';

      seenMacs.set(mac, {
        id: `cpe-${mac}`,
        hostname,
        ipAddress,
        macAddress: mac,
        connectionType,
        online: true,
        connectedSince: Date.now(),
      });
    };

    const parseCollection = (raw: unknown, defaultBand: ConnectionBand) => {
      if (Array.isArray(raw)) {
        for (const item of raw) {
          if (item && typeof item === 'object') {
            const rec = item as Record<string, unknown>;
            addEntry(
              rec.mac_addr ?? rec.mac ?? rec.macAddress ?? rec.sta_mac,
              rec.hostname ?? rec.dev_name ?? rec.host_name ?? rec.name,
              rec.ip_addr ?? rec.ip ?? rec.ipAddress ?? rec.sta_ip,
              rec.connect_type ?? rec.wifi_mode ?? rec.band ?? defaultBand
            );
          } else if (typeof item === 'string') {
            const parts = item.split(',').map((s) => s.trim());
            const mac = parts.find((p) => /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(p));
            const ip = parts.find((p) => /^\d{1,3}(\.\d{1,3}){3}$/.test(p));
            const host = parts.find((p) => p !== mac && p !== ip && p.length > 0);
            if (mac) addEntry(mac, host, ip, defaultBand);
          }
        }
      } else if (typeof raw === 'string' && raw.trim()) {
        for (const row of raw.split(';')) {
          const parts = row.split(',').map((s) => s.trim());
          const mac = parts.find((p) => /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(p));
          const ip = parts.find((p) => /^\d{1,3}(\.\d{1,3}){3}$/.test(p));
          const host = parts.find((p) => p !== mac && p !== ip && p.length > 0);
          if (mac) addEntry(mac, host, ip, defaultBand);
        }
      }
    };

    parseCollection(payload.station_list, '2.4GHz');
    parseCollection(payload.lan_station_list, 'LAN');
    parseCollection(payload.dhcp_client_list, '2.4GHz');

    return Array.from(seenMacs.values());
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
}

export const routerApiService = new RouterApiService();
