import React, { useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Globe,
  RefreshCw,
  RotateCcw,
  Router,
  Terminal,
  Wifi,
  X,
} from 'lucide-react';
import { TranslationStrings } from '../i18n';
import { routerApiService } from '../services/routerApiService';
import { RouterConfig } from '../types';

interface RouterSettingsModalProps {
  config: RouterConfig;
  t: TranslationStrings;
  onClose: () => void;
  onSave: (config: RouterConfig, verifiedLive?: boolean) => void;
  onSyncFromRouter: (config: RouterConfig) => Promise<void>;
  onResetDemoData: () => void;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const RouterSettingsModal: React.FC<RouterSettingsModalProps> = ({
  config,
  t,
  onClose,
  onSave,
  onSyncFromRouter,
  onResetDemoData,
  onNotify,
}) => {
  // Default to Real Router view when opening if user wants to connect, keeping current config intact
  const [draft, setDraft] = useState<RouterConfig>(config);
  const [testing, setTesting] = useState(false);
  const [syncingRules, setSyncingRules] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    text: string;
    detail?: string;
  } | null>(null);

  const handleDownloadBridge = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';
    const script = routerApiService.generateLocalBridgeScript(draft.gatewayIp, origin);
    const blob = new Blob([script], { type: 'application/javascript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bilo-router-bridge.mjs';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onNotify(t.routerModal.bridgeDownloadedToast, 'success');
  };

  const handleCopyCommand = async () => {
    const cmd = 'node bilo-router-bridge.mjs';
    try {
      await navigator.clipboard.writeText(cmd);
    } catch {
      // ignore if restricted
    }
    setCopiedCmd(true);
    onNotify(t.routerModal.commandCopiedToast, 'success');
    window.setTimeout(() => setCopiedCmd(false), 1800);
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const res = await routerApiService.testConnection(draft);
    setTesting(false);

    if (res.isDemo) {
      setTestResult({ ok: true, text: t.routerModal.demoConnectedMsg });
      return;
    }

    if (res.ok) {
      const detailParts: string[] = [];
      if (res.detectedSsid) detailParts.push(`Wi-Fi: ${res.detectedSsid}`);
      if (typeof res.clientCount === 'number') detailParts.push(`${res.clientCount} ${t.devices.connectedCount}`);
      setTestResult({
        ok: true,
        text: t.routerModal.routerConnectedMsg,
        detail: detailParts.join(' · '),
      });
      if (res.detectedSsid) {
        setDraft((prev) => ({ ...prev, ssid24: res.detectedSsid || prev.ssid24 }));
      }
      return;
    }

    const reasonText =
      res.reason === 'mixed_content'
        ? t.routerModal.routerMixedContentMsg
        : res.reason === 'bridge_offline'
          ? t.routerModal.routerBridgeOfflineMsg
          : res.reason === 'auth_failed'
            ? t.routerModal.routerAuthFailedMsg
            : res.reason === 'invalid_host'
              ? t.routerModal.routerInvalidHostMsg
              : t.routerModal.routerUnreachableMsg;

    setTestResult({ ok: false, text: reasonText });
  };

  const handleImportRules = async () => {
    setSyncingRules(true);
    await onSyncFromRouter(draft);
    setSyncingRules(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(draft, testResult?.ok && draft.mode === 'router');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/45 backdrop-blur-[2px] p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-xl bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-200/80 overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sm:hidden pt-3 pb-1 flex justify-center">
          <div className="w-10 h-1.5 rounded-full bg-slate-200" />
        </div>

        <div className="px-5 pt-4 pb-3 border-b border-slate-100 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">{t.routerModal.title}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.routerModal.subtitle}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.common.close}
            className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          {/* Primary Mode Selector: Real Wi-Fi Router vs Demo Mode */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              {t.routerModal.connectionMode}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setDraft({ ...draft, mode: 'router' });
                  setTestResult(null);
                }}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  draft.mode === 'router'
                    ? 'border-[#1565D8] bg-[#EEF4FF]/65 ring-1 ring-[#1565D8]/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <Router className="w-4 h-4 text-[#1565D8] shrink-0" />
                  <span>{t.routerModal.liveTitle}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">{t.routerModal.liveDesc}</p>
              </button>

              <button
                type="button"
                onClick={() => {
                  setDraft({ ...draft, mode: 'demo' });
                  setTestResult(null);
                }}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  draft.mode === 'demo'
                    ? 'border-[#1565D8] bg-[#EEF4FF]/65 ring-1 ring-[#1565D8]/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <Wifi className="w-4 h-4 text-[#1565D8] shrink-0" />
                  <span>{t.routerModal.demoTitle}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">{t.routerModal.demoDesc}</p>
              </button>
            </div>
          </div>

          {/* Real Router Connection Settings */}
          {draft.mode === 'router' && (
            <div className="space-y-4 pt-1 border-t border-slate-100">
              {/* Access Method: Local Wi-Fi Bridge vs Direct LAN */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {t.routerModal.transportLabel}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDraft({ ...draft, transport: 'bridge' });
                      setTestResult(null);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      draft.transport === 'bridge'
                        ? 'border-[#1565D8] bg-[#EEF4FF]/55'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                      <Terminal className="w-3.5 h-3.5 text-[#1565D8] shrink-0" />
                      <span>{t.routerModal.bridgeTitle}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">{t.routerModal.bridgeDesc}</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setDraft({ ...draft, transport: 'direct' });
                      setTestResult(null);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      draft.transport === 'direct'
                        ? 'border-[#1565D8] bg-[#EEF4FF]/55'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                      <Globe className="w-3.5 h-3.5 text-[#1565D8] shrink-0" />
                      <span>{t.routerModal.directTitle}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">{t.routerModal.directDesc}</p>
                  </button>
                </div>
              </div>

              {/* Local Wi-Fi Bridge Setup Box */}
              {draft.transport === 'bridge' && (
                <div className="rounded-xl bg-slate-50 border border-slate-200/90 p-3.5 space-y-2.5">
                  <p className="text-xs font-bold text-slate-800">{t.routerModal.bridgeStepTitle}</p>
                  <div className="space-y-1 text-xs text-slate-600 leading-relaxed">
                    <p>{t.routerModal.bridgeStep1}</p>
                    <p>{t.routerModal.bridgeStep2}</p>
                    <p>{t.routerModal.bridgeStep3}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleDownloadBridge}
                      className="inline-flex items-center gap-1.5 h-10 px-3.5 rounded-xl bg-[#1565D8] hover:bg-[#1052B5] text-white text-xs font-semibold transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{t.routerModal.downloadBridge}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleCopyCommand}
                      className="inline-flex items-center gap-1.5 h-10 px-3 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-xs font-mono font-semibold text-slate-700 transition-colors cursor-pointer"
                    >
                      {copiedCmd ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                      )}
                      <span>node bilo-router-bridge.mjs</span>
                    </button>
                  </div>

                  <div className="pt-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {t.routerModal.bridgeUrl}
                    </label>
                    <input
                      type="text"
                      value={draft.bridgeUrl}
                      onChange={(e) => setDraft({ ...draft, bridgeUrl: e.target.value })}
                      placeholder="http://127.0.0.1:8787"
                      className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-white font-mono text-xs text-slate-900 focus:outline-none focus:border-[#1565D8]"
                    />
                  </div>
                </div>
              )}

              {/* Router Gateway IP & Admin Credentials */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t.routerModal.gatewayIp}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={draft.gatewayIp}
                      onChange={(e) => setDraft({ ...draft, gatewayIp: e.target.value })}
                      placeholder="192.168.0.1"
                      className="flex-1 h-11 px-3.5 rounded-xl border border-slate-200 font-mono text-sm text-slate-900 focus:outline-none focus:border-[#1565D8]"
                    />
                    {(['192.168.0.1', '192.168.1.1', '192.168.8.1'] as const).map((ip) => (
                      <button
                        key={ip}
                        type="button"
                        onClick={() => setDraft({ ...draft, gatewayIp: ip })}
                        className={`h-11 px-2.5 rounded-xl border text-xs font-mono transition-colors cursor-pointer shrink-0 ${
                          draft.gatewayIp === ip
                            ? 'border-[#1565D8] bg-[#EEF4FF] text-[#1565D8] font-semibold'
                            : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        .{ip.split('.').slice(2).join('.')}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      {t.routerModal.username}
                    </label>
                    <input
                      type="text"
                      value={draft.username}
                      onChange={(e) => setDraft({ ...draft, username: e.target.value })}
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-sm text-slate-900 focus:outline-none focus:border-[#1565D8]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      {t.routerModal.password}
                    </label>
                    <input
                      type="password"
                      value={draft.password}
                      onChange={(e) => setDraft({ ...draft, password: e.target.value })}
                      placeholder="admin"
                      autoComplete="off"
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-sm text-slate-900 focus:outline-none focus:border-[#1565D8]"
                    />
                  </div>
                </div>

                <p className="text-[11px] text-slate-500">{t.routerModal.passwordMemoryNote}</p>
              </div>
            </div>
          )}

          {/* Diagnostic Result Box */}
          {testResult && (
            <div
              className={`rounded-xl px-3.5 py-3 text-xs flex items-start gap-2.5 border ${
                testResult.ok
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-amber-50 border-amber-200 text-amber-950'
              }`}
            >
              {testResult.ok ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-0.5">
                <p className="font-medium leading-relaxed">{testResult.text}</p>
                {testResult.detail && (
                  <p className="font-mono text-[11px] text-emerald-700 font-semibold">
                    {testResult.detail}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Utility Actions Row */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleTest}
                disabled={testing}
                className="h-10 px-3.5 rounded-xl border border-[#1565D8]/30 bg-[#EEF4FF]/60 text-xs font-semibold text-[#1565D8] hover:bg-[#EEF4FF] disabled:opacity-60 cursor-pointer"
              >
                {testing ? t.routerModal.testing : t.routerModal.testConnection}
              </button>

              {draft.mode === 'router' && (
                <button
                  type="button"
                  onClick={handleImportRules}
                  disabled={syncingRules}
                  className="inline-flex items-center gap-1.5 h-10 px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${syncingRules ? 'animate-spin' : ''}`} />
                  <span>{t.routerModal.syncFromRouter}</span>
                </button>
              )}
            </div>

            {draft.mode === 'demo' && (
              <button
                type="button"
                onClick={() => {
                  onResetDemoData();
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 h-10 px-3 rounded-xl text-xs font-semibold text-slate-600 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.routerModal.resetDemoData}</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 h-11 rounded-xl border border-slate-200 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="flex-1 h-11 rounded-xl bg-[#1565D8] hover:bg-[#1052B5] text-white text-sm font-semibold transition-colors cursor-pointer"
            >
              {t.routerModal.saveConfig}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
