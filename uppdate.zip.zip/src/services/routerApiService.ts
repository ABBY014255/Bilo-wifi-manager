import { Capacitor, CapacitorHttp } from '@capacitor/core';
import {
  ConnectionBand,
  ConnectedDevice,
  DiagnosticStep,
  FirewallFilterMode,
  FirewallRule,
  RouterConfig,
  RouterFirmwareProtocol,
  RouterNetworkInfo,
  RouterTestResult,
} from '../types';

interface NormalizedResponse {
  status: number;
  ok: boolean;
  text: string;
  json: Record<string, unknown> | null;
  headers: Record<string, string>;
  url?: string;
  location?: string;
  capturedCookie: boolean;
  capturedStok?: string;
}

type ResolvedVariant = Exclude<RouterFirmwareProtocol, 'auto'>;
type VariantCSubmode =
  | 'http_cgi_rpc'
  | 'cgi_login'
  | 'boafrm'
  | 'action_login'
  | 'login_html_token'
  | 'api_login'
  | 'luci'
  | 'http_cgi';

const INITIAL_DEMO_DEVICES: ConnectedDevice[] = [
  {
    id: 'dev-1',
    hostname: 'iPhone-14-Pro',
    ipAddress: '192.168.1.101',
    macAddress: 'A4:83:E7:2B:91:0C',
    connectionType: '5GHz',
    online: true,
    signalStrength: -48,
    connectedSince: Date.now() - 4 * 60 * 60 * 1000,
  },
  {
    id: 'dev-2',
    hostname: 'Galaxy-A15-Juma',
    ipAddress: '192.168.1.104',
    macAddress: '7C:2A:31:F4:88:12',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -61,
    connectedSince: Date.now() - 3 * 60 * 60 * 1000,
  },
  {
    id: 'dev-3',
    hostname: 'TECNO-SPARK-20',
    ipAddress: '192.168.1.108',
    macAddress: 'B8:53:AC:60:4D:71',
    connectionType: '2.4GHz',
    online: true,
    signalStrength: -57,
    connectedSince: Date.now() - 58 * 60 * 1000,
  },
  {
    id: 'dev-4',
    hostname: 'LG-WebOS-SmartTV',
    ipAddress: '192.168.1.112',
    macAddress: 'CC:2D:83:41:5E:19',
    connectionType: 'LAN',
    online: true,
    connectedSince: Date.now() - 18 * 60 * 60 * 1000,
  },
  {
    id: 'dev-5',
    hostname: 'HP-Pavilion-Baraka',
    ipAddress: '192.168.1.115',
    macAddress: 'D8:F2:CA:19:03:AF',
    connectionType: '5GHz',
    online: true,
    signalStrength: -52,
    connectedSince: Date.now() - 2 * 60 * 60 * 1000,
  },
];

const SIMULATED_POOL: Array<{ hostname: string; macAddress: string; connectionType: ConnectionBand }> = [
  { hostname: 'Samsung-Galaxy-A05', macAddress: '8C:F5:A3:44:21:9E', connectionType: '2.4GHz' },
  { hostname: 'iPhone-12-Mini', macAddress: 'F0:18:98:7C:55:B2', connectionType: '5GHz' },
  { hostname: 'TECNO-CAMON-30', macAddress: '64:A2:F9:1E:08:D3', connectionType: '5GHz' },
  { hostname: 'Lenovo-ThinkPad-T14', macAddress: '00:1A:79:B2:46:81', connectionType: 'LAN' },
  { hostname: 'OPPO-A38-Client', macAddress: 'AC:37:43:D9:14:6B', connectionType: '2.4GHz' },
];

const COMMON_GATEWAYS = ['192.168.1.1', '192.168.0.1', '192.168.8.1', '192.168.100.1'] as const;

const PRIVATE_IPV4_RE =
  /^(192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})(:\d{1,5})?$/;

export function isNativeCapacitorRuntime(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

export function cleanGatewayHost(raw: string): string {
  return raw.trim().replace(/^https?:\/\//i, '').replace(/\/+$/, '');
}

export function isValidGatewayHost(raw: string): boolean {
  const cleaned = cleanGatewayHost(raw);
  if (!PRIVATE_IPV4_RE.test(cleaned)) return false;
  const [ipPart, portPart] = cleaned.split(':');
  const octets = ipPart.split('.').map(Number);
  if (octets.length !== 4 || octets.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) {
    return false;
  }
  if (portPart !== undefined) {
    const port = Number(portPart);
    if (!Number.isInteger(port) || port < 1 || port > 65535) return false;
  }
  return true;
}

function safeBase64(input: string): string {
  try {
    const bytes = new TextEncoder().encode(input);
    let binary = '';
    bytes.forEach((b) => {
      binary += String.fromCharCode(b);
    });
    return btoa(binary);
  } catch {
    return btoa(input);
  }
}

const SHA256_K = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

function sha256Hex(input: string): string {
  const bytes = new TextEncoder().encode(input);
  const bitLen = bytes.length * 8;
  const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
  const buf = new Uint8Array(paddedLen);
  buf.set(bytes);
  buf[bytes.length] = 0x80;
  const view = new DataView(buf.buffer);
  view.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000), false);
  view.setUint32(paddedLen - 4, bitLen >>> 0, false);

  let h0 = 0x6a09e667;
  let h1 = 0xbb67ae85;
  let h2 = 0x3c6ef372;
  let h3 = 0xa54ff53a;
  let h4 = 0x510e527f;
  let h5 = 0x9b05688c;
  let h6 = 0x1f83d9ab;
  let h7 = 0x5be0cd19;

  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLen; offset += 64) {
    for (let i = 0; i < 16; i++) {
      w[i] = view.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i++) {
      const s0 =
        ((w[i - 15] >>> 7) | (w[i - 15] << 25)) ^
        ((w[i - 15] >>> 18) | (w[i - 15] << 14)) ^
        (w[i - 15] >>> 3);
      const s1 =
        ((w[i - 2] >>> 17) | (w[i - 2] << 15)) ^
        ((w[i - 2] >>> 19) | (w[i - 2] << 13)) ^
        (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }

    let a = h0;
    let b = h1;
    let c = h2;
    let d = h3;
    let e = h4;
    let f = h5;
    let g = h6;
    let h = h7;

    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + SHA256_K[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    h0 = (h0 + a) >>> 0;
    h1 = (h1 + b) >>> 0;
    h2 = (h2 + c) >>> 0;
    h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0;
    h5 = (h5 + f) >>> 0;
    h6 = (h6 + g) >>> 0;
    h7 = (h7 + h) >>> 0;
  }

  return [h0, h1, h2, h3, h4, h5, h6, h7]
    .map((n) => n.toString(16).padStart(8, '0'))
    .join('');
}

const MD5_S = [
  7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
  5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
  4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
  6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
];

const MD5_K = Array.from({ length: 64 }, (_, i) =>
  Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0
);

function md5Hex(input: string): string {
  const bytes = new TextEncoder().encode(input);
  const bitLen = bytes.length * 8;
  const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
  const buf = new Uint8Array(paddedLen);
  buf.set(bytes);
  buf[bytes.length] = 0x80;
  const view = new DataView(buf.buffer);
  view.setUint32(paddedLen - 8, bitLen >>> 0, true);
  view.setUint32(paddedLen - 4, Math.floor(bitLen / 0x100000000), true);

  let a0 = 0x67452301;
  let b0 = 0xefcdab89;
  let c0 = 0x98badcfe;
  let d0 = 0x10325476;

  const m = new Uint32Array(16);
  for (let offset = 0; offset < paddedLen; offset += 64) {
    for (let i = 0; i < 16; i++) {
      m[i] = view.getUint32(offset + i * 4, true);
    }

    let a = a0;
    let b = b0;
    let c = c0;
    let d = d0;

    for (let i = 0; i < 64; i++) {
      let f = 0;
      let g = 0;
      if (i < 16) {
        f = (b & c) | (~b & d);
        g = i;
      } else if (i < 32) {
        f = (d & b) | (~d & c);
        g = (5 * i + 1) % 16;
      } else if (i < 48) {
        f = b ^ c ^ d;
        g = (3 * i + 5) % 16;
      } else {
        f = c ^ (b | ~d);
        g = (7 * i) % 16;
      }
      const sum = (a + f + MD5_K[i] + m[g]) >>> 0;
      a = d;
      d = c;
      c = b;
      const rot = (sum << MD5_S[i]) | (sum >>> (32 - MD5_S[i]));
      b = (b + rot) >>> 0;
    }

    a0 = (a0 + a) >>> 0;
    b0 = (b0 + b) >>> 0;
    c0 = (c0 + c) >>> 0;
    d0 = (d0 + d) >>> 0;
  }

  const out = new Uint8Array(16);
  const outView = new DataView(out.buffer);
  outView.setUint32(0, a0, true);
  outView.setUint32(4, b0, true);
  outView.setUint32(8, c0, true);
  outView.setUint32(12, d0, true);
  return Array.from(out)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function generate64CharSessionId(): string {
  return (
    md5Hex(`${Math.random()}-${Date.now()}-1`) +
    md5Hex(`${Math.random()}-${Date.now()}-2`)
  ).toLowerCase();
}

function parseJsonSafe(raw: string): Record<string, unknown> | null {
  try {
    const startIdx = raw.indexOf('{');
    const clean = startIdx > 0 ? raw.slice(startIdx) : raw;
    const parsed = JSON.parse(clean);
    if (parsed && typeof parsed === 'object') {
      return parsed as Record<string, unknown>;
    }
    return null;
  } catch {
    return null;
  }
}

function getHeaderCaseInsensitive(
  headers: Record<string, unknown> | undefined,
  name: string
): unknown {
  if (!headers) return undefined;
  const target = name.toLowerCase();
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === target) return value;
  }
  return undefined;
}

class RouterApiService {
  private demoDevices: ConnectedDevice[] = [...INITIAL_DEMO_DEVICES];
  private poolIndex = 0;
  private demoSsid = 'Bilo_WiFi_2.4G';

  private resolvedProtocolByGateway = new Map<string, ResolvedVariant>();
  private resolvedVariantCSubmode = new Map<string, VariantCSubmode>();
  private resolvedVariantLabelByGateway = new Map<string, string>();
  private lastLoginAtByGateway = new Map<string, number>();

  private sessionCookieJar = new Map<string, Map<string, string>>();
  private sessionStokByGateway = new Map<string, string>();
  private sessionTokenByGateway = new Map<string, string>();
  private loginRefererByGateway = new Map<string, string>();
  private lastAuthErrorDetail = '';

  private getGatewayBaseUrl(gatewayIp: string): string {
    return `http://${cleanGatewayHost(gatewayIp)}`;
  }

  private isBrowserHttpsBlocked(): boolean {
    if (isNativeCapacitorRuntime()) return false;
    return typeof window !== 'undefined' && window.location.protocol === 'https:';
  }

  private captureSetCookies(gateway: string, headers?: Record<string, unknown>): boolean {
    if (!headers) return false;
    const rawSetCookie = getHeaderCaseInsensitive(headers, 'set-cookie');
    if (!rawSetCookie) return false;

    const rawList: string[] = Array.isArray(rawSetCookie)
      ? rawSetCookie.map((v) => String(v))
      : [String(rawSetCookie)];

    let jar = this.sessionCookieJar.get(gateway);
    if (!jar) {
      jar = new Map<string, string>();
      this.sessionCookieJar.set(gateway, jar);
    }

    let capturedAny = false;
    for (const headerLine of rawList) {
      const entries = headerLine.split(/,(?=\s*[A-Za-z0-9_.-]+=)/);
      for (const rawCookie of entries) {
        const firstSegment = rawCookie.split(';')[0]?.trim();
        const eqIdx = firstSegment?.indexOf('=') ?? -1;
        if (firstSegment && eqIdx > 0) {
          const name = firstSegment.slice(0, eqIdx).trim();
          const value = firstSegment.slice(eqIdx + 1).trim();
          if (name && value && value.toLowerCase() !== 'deleted') {
            jar.set(name, value);
            capturedAny = true;
          }
        }
      }
    }

    return capturedAny;
  }

  private getCookieHeader(gateway: string): string {
    const jar = this.sessionCookieJar.get(gateway);
    if (!jar || jar.size === 0) return '';
    return Array.from(jar.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }

  private clearGatewaySession(gateway: string): void {
    this.lastLoginAtByGateway.delete(gateway);
    this.sessionCookieJar.delete(gateway);
    this.sessionStokByGateway.delete(gateway);
    this.sessionTokenByGateway.delete(gateway);
    this.lastAuthErrorDetail = '';
  }

  private async sendRouterRequest(
    config: RouterConfig,
    routerPath: string,
    options: {
      method: 'GET' | 'POST';
      body?: string;
      contentType?: string;
      timeoutMs?: number;
      gatewayOverride?: string;
      refererPath?: string;
      disableRedirects?: boolean;
    }
  ): Promise<NormalizedResponse> {
    const gateway = cleanGatewayHost(options.gatewayOverride ?? config.gatewayIp);
    const baseUrl = this.getGatewayBaseUrl(gateway);
    const url = `${baseUrl}${routerPath}`;
    const timeoutMs = options.timeoutMs ?? 5000;
    const cookieHeader = this.getCookieHeader(gateway);
    const refererPath = options.refererPath ?? this.loginRefererByGateway.get(gateway) ?? '/login.html';

    const requestHeaders: Record<string, string> = {
      Referer: `${baseUrl}${refererPath}`,
      Origin: baseUrl,
      ...(options.method === 'POST'
        ? {
            'Content-Type':
              options.contentType ?? 'application/x-www-form-urlencoded; charset=UTF-8',
          }
        : {}),
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
    };

    if (isNativeCapacitorRuntime()) {
      const response = await CapacitorHttp.request({
        url,
        method: options.method,
        headers: requestHeaders,
        data: options.body,
        connectTimeout: timeoutMs,
        readTimeout: timeoutMs,
        shouldEncodeUrlParams: false,
        ...(options.disableRedirects ? { disableRedirects: true } : {}),
      });

      const rawHeaders = (response.headers ?? {}) as Record<string, unknown>;
      const capturedCookie = this.captureSetCookies(gateway, rawHeaders);

      const normalizedHeaders: Record<string, string> = {};
      for (const [k, v] of Object.entries(rawHeaders)) {
        normalizedHeaders[k.toLowerCase()] = Array.isArray(v) ? v.join(', ') : String(v ?? '');
      }

      const text =
        typeof response.data === 'string'
          ? response.data
          : response.data != null
            ? JSON.stringify(response.data)
            : '';
      const json =
        response.data && typeof response.data === 'object'
          ? (response.data as Record<string, unknown>)
          : parseJsonSafe(text);

      return {
        status: response.status,
        ok: response.status >= 200 && response.status < 400,
        text,
        json,
        headers: normalizedHeaders,
        url: response.url,
        location: normalizedHeaders['location'],
        capturedCookie,
      };
    }

    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        method: options.method,
        credentials: 'include',
        redirect: options.disableRedirects ? 'manual' : 'follow',
        headers:
          options.method === 'POST'
            ? {
                'Content-Type':
                  options.contentType ?? 'application/x-www-form-urlencoded; charset=UTF-8',
              }
            : undefined,
        body: options.body,
        signal: controller.signal,
      });
      window.clearTimeout(timer);
      const text = await res.text();
      const json = parseJsonSafe(text);
      return {
        status: res.status,
        ok: res.status >= 200 && res.status < 400,
        text,
        json,
        headers: {},
        url: res.url,
        capturedCookie: false,
      };
    } catch (err) {
      window.clearTimeout(timer);
      throw err;
    }
  }

  /**
   * Direct helper for Airtel Tanzania Tozed/ZLT `/cgi-bin/http.cgi` JSON-RPC commands.
   * Matches `Page.postJSON` in `js/main.js` and `js/login.js`.
   */
  private async postHttpCgi(
    config: RouterConfig,
    payload: Record<string, unknown>,
    options?: { timeoutMs?: number; omitAutoToken?: boolean }
  ): Promise<NormalizedResponse> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const storedSessionId = this.sessionStokByGateway.get(gateway) ?? '';
    const storedToken = this.sessionTokenByGateway.get(gateway);
    const method = String(payload.method ?? 'GET').toUpperCase();

    const fullPayload: Record<string, unknown> = {
      method,
      language: 'EN',
      sessionId: payload.sessionId !== undefined ? payload.sessionId : storedSessionId,
      ...(!options?.omitAutoToken && method === 'POST' && storedToken && payload.token === undefined
        ? { token: storedToken }
        : {}),
      ...payload,
    };

    const res = await this.sendRouterRequest(config, '/cgi-bin/http.cgi', {
      method: 'POST',
      contentType: 'text/plain;charset=UTF-8',
      body: JSON.stringify(fullPayload),
      refererPath: '/login.html',
      timeoutMs: options?.timeoutMs ?? 5000,
    });

    if (res.json && typeof res.json.token === 'string' && res.json.token.trim()) {
      this.sessionTokenByGateway.set(gateway, res.json.token.trim());
    }

    return res;
  }

  async detectGatewayIp(
    config: RouterConfig
  ): Promise<{ foundIp: string | null; blockedByHttps?: boolean }> {
    if (this.isBrowserHttpsBlocked()) {
      return { foundIp: null, blockedByHttps: true };
    }

    const candidates = Array.from(
      new Set([cleanGatewayHost(config.gatewayIp), ...COMMON_GATEWAYS].filter(isValidGatewayHost))
    );

    for (const ip of candidates) {
      for (const probePath of ['/login.html', '/index.html']) {
        try {
          const res = await this.sendRouterRequest(config, probePath, {
            method: 'GET',
            timeoutMs: 2000,
            gatewayOverride: ip,
            refererPath: probePath,
          });
          if (res.status > 0 && res.status < 400) {
            this.loginRefererByGateway.set(ip, probePath);
            return { foundIp: ip };
          }
        } catch {
          // try next
        }
      }
    }
    return { foundIp: null };
  }

  /**
   * Exact Airtel Tanzania 5G CPE Tozed/ZLT JSON-RPC Login (`/cgi-bin/http.cgi`):
   * Matches `js/login.js`:
   *   1. POST `{"cmd":232,"method":"GET","sessionId":"","language":"EN"}` -> get `data.token`
   *   2. Compute `sha256_digest(token + passwd)` (tries both lowercase and UPPERCASE)
   *   3. POST `{"cmd":100,"method":"POST","sessionId":sessionId,"username":username,"passwd":digest,"isAutoUpgrade":"0","subcmd":0,"language":"EN"}`
   */
  private async loginAirtelHttpCgiRpc(
    config: RouterConfig
  ): Promise<{
    ok: boolean;
    authRejected?: boolean;
    variantLabel?: string;
    detail?: string;
  }> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const username = config.username.trim() || 'admin';
    const plainPassword = config.password || 'admin';

    // Step 1: Fetch login token (cmd: 232)
    let token = '';
    try {
      const step1 = await this.postHttpCgi(
        config,
        {
          cmd: 232,
          method: 'GET',
          sessionId: '',
          language: 'EN',
        },
        { timeoutMs: 4000, omitAutoToken: true }
      );

      if (step1.status === 404 || step1.status === 405 || step1.status >= 500 || !step1.json) {
        return { ok: false, detail: '/cgi-bin/http.cgi cmd=232 unsupported' };
      }

      if (typeof step1.json.token === 'string') {
        token = step1.json.token.trim();
      }
    } catch {
      return { ok: false, detail: '/cgi-bin/http.cgi unreachable' };
    }

    const digestLower = sha256Hex(`${token}${plainPassword}`).toLowerCase();
    const digestUpper = digestLower.toUpperCase();
    const shaOnlyLower = sha256Hex(plainPassword).toLowerCase();

    // Try exact `js/login.js` payload first (without extra `token` key in cmd 100, lowercase & uppercase SHA256)
    const loginAttempts: Array<{ passwd: string; includeToken: boolean; label: string }> = [
      { passwd: digestLower, includeToken: false, label: 'sha256-lower(token+pass)' },
      { passwd: digestUpper, includeToken: false, label: 'SHA256-UPPER(token+pass)' },
      { passwd: digestLower, includeToken: true, label: 'sha256-lower+token' },
      { passwd: shaOnlyLower, includeToken: false, label: 'sha256(pass)' },
    ];

    for (const attempt of loginAttempts) {
      const sessionId = generate64CharSessionId();
      try {
        // Re-fetch fresh token before subsequent attempts if first attempt was rejected
        if (attempt !== loginAttempts[0]) {
          const refreshTokenRes = await this.postHttpCgi(
            config,
            { cmd: 232, method: 'GET', sessionId: '', language: 'EN' },
            { timeoutMs: 3000, omitAutoToken: true }
          );
          if (refreshTokenRes.json && typeof refreshTokenRes.json.token === 'string') {
            token = refreshTokenRes.json.token.trim();
            if (attempt.label.includes('UPPER')) {
              attempt.passwd = sha256Hex(`${token}${plainPassword}`).toUpperCase();
            } else if (attempt.label.includes('token+pass')) {
              attempt.passwd = sha256Hex(`${token}${plainPassword}`).toLowerCase();
            }
          }
        }

        const loginPayload: Record<string, unknown> = {
          cmd: 100,
          method: 'POST',
          sessionId,
          username,
          passwd: attempt.passwd,
          isAutoUpgrade: '0',
          subcmd: 0,
          language: 'EN',
          ...(attempt.includeToken && token ? { token } : {}),
        };

        const step2 = await this.postHttpCgi(config, loginPayload, {
          timeoutMs: 5000,
          omitAutoToken: true,
        });

        if (!step2.json) continue;
        const data = step2.json;

        // Check if router locked out login attempts (180s cooldown in js/login.js)
        if (data.login_fail2 === 'fail') {
          const waitSec = Number(data.login_time ?? 180);
          this.lastAuthErrorDetail = `Router locked for ${waitSec}s (too many attempts)`;
          return {
            ok: false,
            authRejected: true,
            detail: this.lastAuthErrorDetail,
          };
        }

        if (data.success === true && data.login_fail !== 'fail') {
          const returnedSessionId =
            typeof data.sessionId === 'string' && data.sessionId.trim().length > 0
              ? data.sessionId.trim()
              : sessionId;
          this.sessionStokByGateway.set(gateway, returnedSessionId);
          if (typeof data.token === 'string' && data.token.trim().length > 0) {
            this.sessionTokenByGateway.set(gateway, data.token.trim());
          } else if (token) {
            this.sessionTokenByGateway.set(gateway, token);
          }

          // Call RESET_LOGIN_TIME (cmd: 233) to obtain fresh POST token just like resetTime() in main.js
          try {
            const resetRes = await this.postHttpCgi(
              config,
              {
                cmd: 233,
                method: 'GET',
                sessionId: returnedSessionId,
                language: 'EN',
              },
              { timeoutMs: 3000, omitAutoToken: true }
            );
            if (resetRes.json && typeof resetRes.json.token === 'string' && resetRes.json.token.trim()) {
              this.sessionTokenByGateway.set(gateway, resetRes.json.token.trim());
            }
          } catch {
            // optional
          }

          return {
            ok: true,
            variantLabel: `Airtel 5G Tozed RPC (${attempt.label})`,
            detail: `cmd=100 OK (${attempt.label})`,
          };
        }

        if (data.login_fail === 'fail') {
          const attemptsLeft = data.login_times !== undefined ? ` (${data.login_times} tries left)` : '';
          this.lastAuthErrorDetail = `Wrong username or password${attemptsLeft}`;
        }
      } catch {
        // continue trying next digest format
      }
    }

    return {
      ok: false,
      authRejected: true,
      detail: this.lastAuthErrorDetail || 'Wrong username or password',
    };
  }

  private async loginGoformOrReqproc(
    config: RouterConfig,
    variant: 'goform' | 'reqproc'
  ): Promise<{ ok: boolean; authRejected?: boolean; variantLabel?: string; detail?: string }> {
    const username = config.username.trim() || 'admin';
    const plainPassword = config.password || 'admin';
    const base64Password = safeBase64(plainPassword);
    const postPath =
      variant === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';

    for (const candidate of [
      { value: base64Password, encoding: 'base64' },
      { value: plainPassword, encoding: 'plain' },
    ]) {
      try {
        const res = await this.sendRouterRequest(config, postPath, {
          method: 'POST',
          body: new URLSearchParams({
            isTest: 'false',
            goformId: 'LOGIN',
            username,
            password: candidate.value,
          }).toString(),
          refererPath: '/login.html',
        });
        if (res.status === 404 || res.status === 405 || res.status >= 500) {
          return { ok: false, detail: `${postPath} HTTP ${res.status}` };
        }
        const resultVal = String(res.json?.result ?? '').trim().toLowerCase();
        if (resultVal === '0' || resultVal === '4' || resultVal === 'success') {
          return { ok: true, variantLabel: `${variant} (${candidate.encoding})` };
        }
      } catch {
        return { ok: false };
      }
    }

    return { ok: false };
  }

  private async ensureAuthenticated(config: RouterConfig): Promise<{
    ok: boolean;
    protocol: ResolvedVariant;
    variantLabel?: string;
    authRejected?: boolean;
    detail?: string;
  }> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const cachedProto =
      config.firmwareProtocol !== 'auto'
        ? config.firmwareProtocol
        : this.resolvedProtocolByGateway.get(gateway);
    const lastLogin = this.lastLoginAtByGateway.get(gateway) ?? 0;

    if (cachedProto && Date.now() - lastLogin < 3 * 60 * 1000) {
      return {
        ok: true,
        protocol: cachedProto,
        variantLabel: this.resolvedVariantLabelByGateway.get(gateway),
      };
    }

    const recordSuccess = (
      protocol: ResolvedVariant,
      variantLabel: string,
      submode?: VariantCSubmode
    ) => {
      this.resolvedProtocolByGateway.set(gateway, protocol);
      if (submode) this.resolvedVariantCSubmode.set(gateway, submode);
      this.resolvedVariantLabelByGateway.set(gateway, variantLabel);
      this.lastLoginAtByGateway.set(gateway, Date.now());
      return { ok: true, protocol, variantLabel };
    };

    if (config.firmwareProtocol === 'auto' || config.firmwareProtocol === 'tozed_web') {
      const rpcRes = await this.loginAirtelHttpCgiRpc(config);
      if (rpcRes.ok) {
        return recordSuccess(
          'tozed_web',
          rpcRes.variantLabel || 'Airtel 5G Tozed RPC',
          'http_cgi_rpc'
        );
      }
      if (rpcRes.authRejected) {
        return {
          ok: false,
          protocol: 'tozed_web',
          authRejected: true,
          detail: rpcRes.detail,
        };
      }
    }

    if (config.firmwareProtocol === 'auto' || config.firmwareProtocol === 'goform') {
      const methodA = await this.loginGoformOrReqproc(config, 'goform');
      if (methodA.ok) {
        return recordSuccess('goform', methodA.variantLabel || 'goform');
      }
    }

    if (config.firmwareProtocol === 'auto' || config.firmwareProtocol === 'reqproc') {
      const reqRes = await this.loginGoformOrReqproc(config, 'reqproc');
      if (reqRes.ok) {
        return recordSuccess('reqproc', reqRes.variantLabel || 'reqproc');
      }
    }

    return {
      ok: false,
      protocol: cachedProto ?? 'tozed_web',
      authRejected: Boolean(this.lastAuthErrorDetail),
      detail: this.lastAuthErrorDetail,
    };
  }

  private async queryRouterData(
    config: RouterConfig,
    protocol: ResolvedVariant,
    cmds: string
  ): Promise<Record<string, unknown> | null> {
    const gateway = cleanGatewayHost(config.gatewayIp);
    const stok = this.sessionStokByGateway.get(gateway);
    const submode = this.resolvedVariantCSubmode.get(gateway);

    if (submode === 'http_cgi_rpc' || (protocol === 'tozed_web' && stok && stok.length >= 32)) {
      const merged: Record<string, unknown> = {};
      const rpcCmds = [
        223, // DHCPCLIENT_INFO
        208, // LAN_INFO
        133, // ROUTER_INFO
        113, // GET_SYS_STATUS
        209, // WIFI_INFO
        210, // WIFI5G_INFO
        278, // WIRELESS_MACFILTER
        23,  // MAC_FILTER
      ];
      let gotAny = false;
      for (const cmd of rpcCmds) {
        try {
          const res = await this.postHttpCgi(config, {
            cmd,
            method: 'GET',
            sessionId: stok ?? '',
            language: 'EN',
          });
          if (res.ok && res.json && res.json.success !== false) {
            Object.assign(merged, res.json);
            gotAny = true;
          }
        } catch {
          // continue
        }
      }
      if (gotAny) return merged;
    }

    if (protocol === 'goform') {
      const res = await this.sendRouterRequest(
        config,
        `/goform/goform_get_cmd_process?isTest=false&cmd=${cmds}&multi_data=1`,
        { method: 'GET' }
      );
      return res.ok && res.json ? res.json : null;
    }

    if (protocol === 'reqproc') {
      const res = await this.sendRouterRequest(
        config,
        `/reqproc/proc_get?isTest=false&cmd=${cmds}&multi_data=1`,
        { method: 'GET' }
      );
      return res.ok && res.json ? res.json : null;
    }

    return null;
  }

  private parseNetworkInfo(payload: Record<string, unknown>, fallbackSsid: string): RouterNetworkInfo {
    const ssid24 = String(
      payload.SSID1 || payload.m_SSID1 || payload.ssid || payload.wifi_ssid || fallbackSsid
    ).trim();
    const ssid5 =
      String(payload.SSID2 || payload.wifi_5g_ssid || payload.ssid5g || '').trim() || undefined;
    const networkProvider =
      String(
        payload.network_provider ||
          payload.network_operator ||
          payload.spn_name_data ||
          payload.plmn_name ||
          ''
      ).trim() || undefined;
    const networkType =
      String(
        payload.network_type_str ||
          payload.network_type ||
          payload.net_mode ||
          payload.wan_mode ||
          ''
      ).trim() || undefined;
    const signalBarRaw = Number(payload.signal_lvl ?? payload.signalbar ?? payload.signal_bar ?? NaN);
    const signalBar = Number.isFinite(signalBarRaw)
      ? Math.max(0, Math.min(5, Math.round(signalBarRaw)))
      : undefined;
    const rawRssi = payload.RSSI ?? payload.rssi;
    const rssi = rawRssi != null && String(rawRssi).trim() !== '' ? `${rawRssi} dBm` : undefined;
    const rawRsrp = payload.RSRP ?? payload.lte_rsrp;
    const rsrp = rawRsrp != null && String(rawRsrp).trim() !== '' ? `${rawRsrp} dBm` : undefined;
    const wanIp =
      String(payload.wan_ip || payload.wan_ipaddr || payload.ppp_ipaddr || '').trim() || undefined;
    const hardwareVersion =
      String(payload.hardware_version || payload.device_type || payload.wa_inner_version || '').trim() ||
      undefined;
    const firmwareVersion =
      String(payload.fake_version || payload.real_fwversion || payload.cr_version || '').trim() ||
      undefined;

    return {
      ssid24,
      ssid5,
      networkProvider,
      networkType,
      signalBar,
      rssi,
      rsrp,
      wanIp,
      hardwareVersion,
      firmwareVersion,
    };
  }

  async testConnection(config: RouterConfig): Promise<RouterTestResult> {
    if (config.mode === 'demo') {
      await this.delay(180);
      return {
        ok: true,
        isDemo: true,
        message: 'Demo mode ready',
        networkInfo: {
          ssid24: this.demoSsid,
          ssid5: config.ssid5,
          networkProvider: 'Airtel TZ (Demo)',
          networkType: '5G NSA',
          signalBar: 4,
          rssi: '-64 dBm',
          wanIp: '105.231.42.18',
          hardwareVersion: 'ZLT X28 5G',
        },
      };
    }

    const steps: DiagnosticStep[] = [];

    if (!isValidGatewayHost(config.gatewayIp)) {
      return {
        ok: false,
        isDemo: false,
        reason: 'invalid_host',
        message: 'Invalid private LAN gateway IP address',
      };
    }

    if (this.isBrowserHttpsBlocked()) {
      return {
        ok: false,
        isDemo: false,
        reason: 'mixed_content',
        message: 'Direct HTTP to router LAN requires Android APK (Capacitor) or local HTTP.',
      };
    }

    const gateway = cleanGatewayHost(config.gatewayIp);
    let gatewayReached = false;
    let reachedStatus = 0;
    let reachedPath = '/login.html';

    for (const probePath of ['/login.html', '/index.html']) {
      try {
        const probeRes = await this.sendRouterRequest(config, probePath, {
          method: 'GET',
          timeoutMs: 3000,
          refererPath: probePath,
        });
        if (probeRes.status > 0 && probeRes.status < 500) {
          gatewayReached = true;
          reachedStatus = probeRes.status;
          reachedPath = probePath;
          if (probeRes.status < 400) {
            this.loginRefererByGateway.set(gateway, probePath);
            break;
          }
        }
      } catch {
        // try next
      }
    }

    if (!gatewayReached) {
      steps.push({
        id: 'gateway',
        label: `Router ${gateway}`,
        status: 'fail',
        detail: 'No response on LAN',
      });
      return {
        ok: false,
        isDemo: false,
        reason: 'gateway_unreachable',
        message: `Router ${gateway} unreachable`,
        steps,
      };
    }

    steps.push({
      id: 'gateway',
      label: `Router ${gateway}`,
      status: 'ok',
      detail: `${reachedPath} · HTTP ${reachedStatus}`,
    });

    this.clearGatewaySession(gateway);
    const auth = await this.ensureAuthenticated(config);
    if (!auth.ok) {
      const failDetail =
        auth.detail ||
        (auth.authRejected
          ? 'Wrong username or password'
          : 'Router API login endpoint not accepted');
      steps.push({
        id: 'login',
        label: 'Router Admin Login',
        status: 'fail',
        detail: failDetail,
      });
      return {
        ok: false,
        isDemo: false,
        reason: auth.authRejected ? 'auth_failed' : 'network_error',
        message: failDetail,
        steps,
      };
    }

    steps.push({
      id: 'login',
      label: 'Router Admin Login',
      status: 'ok',
      detail: auth.variantLabel || auth.protocol,
    });

    let clientCount = 0;
    let networkInfo: RouterNetworkInfo | undefined;
    try {
      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'station_list,dhcp_list,lan_station_list,SSID1,m_SSID1,network_provider,network_type,signalbar,rssi,lte_rsrp,wan_ipaddr,hardware_version'
      );
      if (payload) {
        clientCount = this.parseZltStationPayload(payload).length;
        networkInfo = this.parseNetworkInfo(payload, config.ssid24);
      }
      steps.push({
        id: 'clients',
        label: 'Clients & Network Info',
        status: 'ok',
        detail: `${clientCount} clients`,
      });
    } catch {
      steps.push({
        id: 'clients',
        label: 'Clients & Network Info',
        status: 'fail',
        detail: 'Could not read station_list',
      });
    }

    return {
      ok: true,
      isDemo: false,
      message: 'Connected',
      detectedSsid: networkInfo?.ssid24,
      detectedProtocol: auth.protocol,
      detectedVariantLabel: auth.variantLabel,
      clientCount,
      networkInfo,
      steps,
    };
  }

  async getConnectedDevices(
    config: RouterConfig
  ): Promise<{ devices: ConnectedDevice[]; connectedLive: boolean; fallbackUsed: boolean }> {
    if (config.mode === 'demo') {
      await this.delay(150);
      return { devices: [...this.demoDevices], connectedLive: false, fallbackUsed: false };
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return { devices: [], connectedLive: false, fallbackUsed: true };
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) {
        return { devices: [], connectedLive: false, fallbackUsed: true };
      }

      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'station_list,dhcp_list,lan_station_list'
      );
      if (!payload) {
        return { devices: [], connectedLive: false, fallbackUsed: true };
      }
      const parsed = this.parseZltStationPayload(payload);
      return { devices: parsed, connectedLive: true, fallbackUsed: false };
    } catch {
      return { devices: [], connectedLive: false, fallbackUsed: true };
    }
  }

  async getRouterNetworkInfo(config: RouterConfig): Promise<RouterNetworkInfo | null> {
    if (config.mode === 'demo') {
      await this.delay(140);
      return {
        ssid24: this.demoSsid,
        ssid5: config.ssid5,
        networkProvider: 'Airtel TZ (Demo)',
        networkType: '5G NSA',
        signalBar: 4,
        rssi: '-64 dBm',
        rsrp: '-88 dBm',
        wanIp: '105.231.42.18',
        hardwareVersion: 'ZLT X28 5G',
      };
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return null;
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return null;
      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'SSID1,SSID2,m_SSID1,network_provider,network_type,signalbar,rssi,lte_rsrp,wan_ipaddr,hardware_version,wa_inner_version'
      );
      if (!payload) return null;
      return this.parseNetworkInfo(payload, config.ssid24);
    } catch {
      return null;
    }
  }

  async updateWifiSettings(
    config: RouterConfig,
    params: { ssid: string; wifiPassword: string }
  ): Promise<{ ok: boolean; error?: string }> {
    const cleanSsid = params.ssid.trim();
    const cleanPass = params.wifiPassword;
    if (!cleanSsid || cleanSsid.length > 32) {
      return { ok: false, error: 'SSID must be 1-32 characters' };
    }
    if (cleanPass && (cleanPass.length < 8 || cleanPass.length > 63)) {
      return { ok: false, error: 'Wi-Fi password must be 8-63 characters' };
    }

    if (config.mode === 'demo') {
      await this.delay(180);
      this.demoSsid = cleanSsid;
      return { ok: true };
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return { ok: false, error: 'Router unreachable' };
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return { ok: false, error: 'Router login required' };

      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      if (submode === 'http_cgi_rpc') {
        const res = await this.postHttpCgi(config, {
          cmd: 2,
          method: 'POST',
          ssid: cleanSsid,
          SSID1: cleanSsid,
          ...(cleanPass ? { key: cleanPass, passphrase: cleanPass, WPAPSK1: cleanPass } : {}),
        });
        return { ok: res.ok && res.json?.success !== false };
      }

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const body = new URLSearchParams({
        isTest: 'false',
        goformId: 'SET_WIFI_INFO',
        m_ssid: cleanSsid,
        SSID1: cleanSsid,
        ...(cleanPass
          ? {
              passphrase: cleanPass,
              WPAPSK1: cleanPass,
              AuthMode: 'WPA2PSK',
              EncrypType: 'AES',
            }
          : {}),
      }).toString();

      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body,
      });
      return { ok: res.ok };
    } catch {
      return { ok: false, error: 'Failed to update Wi-Fi settings' };
    }
  }

  async rebootRouter(config: RouterConfig): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(220);
      return true;
    }

    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return false;
    }

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return false;

      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      if (submode === 'http_cgi_rpc') {
        const res = await this.postHttpCgi(config, {
          cmd: 6,
          rebootType: 1,
          method: 'POST',
        });
        return res.ok;
      }

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'REBOOT_DEVICE',
        }).toString(),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  async fetchRouterFirewallState(
    config: RouterConfig
  ): Promise<{ ok: boolean; mode?: FirewallFilterMode; macs?: string[] }> {
    if (config.mode !== 'router' || !isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) {
      return { ok: false };
    }
    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return { ok: false };

      const payload = await this.queryRouterData(
        config,
        auth.protocol,
        'mac_filter_mode,mac_filter_list'
      );
      if (!payload) return { ok: false };

      const rawMode = String(payload.mac_filter_mode ?? payload.macFilterMode ?? '0');
      const mode: FirewallFilterMode =
        rawMode === '1' ? 'whitelist' : rawMode === '2' ? 'blacklist' : 'disabled';

      const macs: string[] = [];
      const rawList = payload.mac_filter_list ?? payload.macList ?? payload.wifi_mac_list;
      if (Array.isArray(rawList)) {
        for (const item of rawList) {
          const mac =
            typeof item === 'string'
              ? item
              : String((item as Record<string, unknown>)?.mac ?? '');
          if (mac.includes(':')) macs.push(mac.trim().toUpperCase());
        }
      } else if (typeof rawList === 'string' && rawList.trim()) {
        for (const token of rawList.split(/[;,]/)) {
          const cleaned = token.trim().toUpperCase();
          if (/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(cleaned)) {
            macs.push(cleaned);
          }
        }
      }

      return { ok: true, mode, macs };
    } catch {
      return { ok: false };
    }
  }

  simulateClientConnect(): ConnectedDevice {
    const candidate = SIMULATED_POOL[this.poolIndex % SIMULATED_POOL.length];
    this.poolIndex += 1;

    const newDevice: ConnectedDevice = {
      id: `dev-sim-${Date.now()}`,
      hostname: candidate.hostname,
      ipAddress: `192.168.1.${130 + this.demoDevices.length}`,
      macAddress: candidate.macAddress,
      connectionType: candidate.connectionType,
      online: true,
      signalStrength: candidate.connectionType === 'LAN' ? undefined : -55,
      connectedSince: Date.now(),
    };
    this.demoDevices = [newDevice, ...this.demoDevices];
    return newDevice;
  }

  async setMacFilterMode(config: RouterConfig, mode: FirewallFilterMode): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(100);
      return true;
    }
    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) return false;

    const routerModeCode = mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0';
    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return false;
      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      if (submode === 'http_cgi_rpc') {
        await this.postHttpCgi(config, {
          cmd: 278,
          method: 'POST',
          mac_filter_mode: routerModeCode,
          macFilterMode: routerModeCode,
        });
        await this.postHttpCgi(config, {
          cmd: 23,
          method: 'POST',
          mac_filter_mode: routerModeCode,
        });
        const applyRes = await this.postHttpCgi(config, {
          cmd: 20,
          method: 'POST',
        });
        return applyRes.ok;
      }

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'SET_MAC_FILTER_MODE',
          mac_filter_mode: routerModeCode,
        }).toString(),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  async syncFirewallRules(
    config: RouterConfig,
    mode: FirewallFilterMode,
    rules: FirewallRule[]
  ): Promise<boolean> {
    if (config.mode === 'demo') {
      await this.delay(100);
      return true;
    }
    if (!isValidGatewayHost(config.gatewayIp) || this.isBrowserHttpsBlocked()) return false;

    const effectiveMacs =
      mode === 'whitelist'
        ? rules.filter((r) => r.enabled && !r.expired).map((r) => r.macAddress)
        : mode === 'blacklist'
          ? rules.filter((r) => r.enabled || r.expired).map((r) => r.macAddress)
          : [];

    const routerModeCode = mode === 'whitelist' ? '1' : mode === 'blacklist' ? '2' : '0';

    try {
      const auth = await this.ensureAuthenticated(config);
      if (!auth.ok) return false;
      const gateway = cleanGatewayHost(config.gatewayIp);
      const submode = this.resolvedVariantCSubmode.get(gateway);

      if (submode === 'http_cgi_rpc') {
        await this.postHttpCgi(config, {
          cmd: 278,
          method: 'POST',
          mac_filter_mode: routerModeCode,
          mac_filter_enable: mode === 'disabled' ? '0' : '1',
          mac_filter_list: effectiveMacs.join(';'),
          macList: effectiveMacs,
        });
        await this.postHttpCgi(config, {
          cmd: 23,
          method: 'POST',
          mac_filter_mode: routerModeCode,
          mac_filter_enable: mode === 'disabled' ? '0' : '1',
          mac_filter_list: effectiveMacs.join(';'),
        });
        const applyRes = await this.postHttpCgi(config, {
          cmd: 20,
          method: 'POST',
        });
        return applyRes.ok;
      }

      const postPath =
        auth.protocol === 'reqproc' ? '/reqproc/proc_post' : '/goform/goform_set_cmd_process';
      const res = await this.sendRouterRequest(config, postPath, {
        method: 'POST',
        body: new URLSearchParams({
          isTest: 'false',
          goformId: 'SET_MAC_FILTER',
          mac_filter_mode: routerModeCode,
          mac_filter_enable: mode === 'disabled' ? '0' : '1',
          mac_filter_list: effectiveMacs.join(';'),
        }).toString(),
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  private parseZltStationPayload(payload: Record<string, unknown>): ConnectedDevice[] {
    const seenMacs = new Map<string, ConnectedDevice>();

    const addEntry = (
      macRaw: unknown,
      hostnameRaw: unknown,
      ipRaw: unknown,
      bandRaw: unknown
    ) => {
      const mac = String(macRaw || '').trim().toUpperCase().replace(/-/g, ':');
      if (!/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(mac)) return;
      if (seenMacs.has(mac)) return;

      const bandStr = String(bandRaw || '2.4GHz').toLowerCase();
      const connectionType: ConnectionBand =
        bandStr.includes('5g') || bandStr.includes('5.8') || bandStr === '5'
          ? '5GHz'
          : bandStr.includes('lan') || bandStr.includes('eth') || bandStr.includes('wired')
            ? 'LAN'
            : '2.4GHz';

      const hostname =
        String(hostnameRaw || '').trim() || `Client-${mac.slice(-5).replace(':', '')}`;
      const ipAddress = String(ipRaw || '').trim() || '192.168.1.x';

      seenMacs.set(mac, {
        id: `cpe-${mac}`,
        hostname,
        ipAddress,
        macAddress: mac,
        connectionType,
        online: true,
        connectedSince: Date.now(),
      });
    };

    const parseCollection = (raw: unknown, defaultBand: ConnectionBand) => {
      if (Array.isArray(raw)) {
        for (const item of raw) {
          if (item && typeof item === 'object') {
            const rec = item as Record<string, unknown>;
            addEntry(
              rec.mac_addr ?? rec.mac ?? rec.macAddress ?? rec.sta_mac ?? rec.macaddr,
              rec.hostname ?? rec.dev_name ?? rec.host_name ?? rec.name ?? rec.device_name,
              rec.ip_addr ?? rec.ip ?? rec.ipAddress ?? rec.sta_ip ?? rec.ipaddr,
              rec.connect_type ?? rec.wifi_mode ?? rec.band ?? rec.interface ?? defaultBand
            );
          } else if (typeof item === 'string') {
            const parts = item.split(',').map((s) => s.trim());
            const mac = parts.find((p) => /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(p));
            const ip = parts.find((p) => /^\d{1,3}(\.\d{1,3}){3}$/.test(p));
            const host = parts.find((p) => p !== mac && p !== ip && p.length > 0);
            if (mac) addEntry(mac, host, ip, defaultBand);
          }
        }
      } else if (typeof raw === 'string' && raw.trim()) {
        for (const row of raw.split(';')) {
          const parts = row.split(',').map((s) => s.trim());
          const mac = parts.find((p) => /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(p));
          const ip = parts.find((p) => /^\d{1,3}(\.\d{1,3}){3}$/.test(p));
          const host = parts.find((p) => p !== mac && p !== ip && p.length > 0);
          if (mac) addEntry(mac, host, ip, defaultBand);
        }
      }
    };

    parseCollection(payload.dhcp_client_list, '2.4GHz');
    parseCollection(payload.dhcp_list, '2.4GHz');
    parseCollection(payload.station_list, '2.4GHz');
    parseCollection(payload.wifi24g_list, '2.4GHz');
    parseCollection(payload.wifi5g_list, '5GHz');
    parseCollection(payload.lan_station_list, 'LAN');
    parseCollection(payload.lan_list, 'LAN');
    parseCollection(payload.leases, '2.4GHz');
    parseCollection(payload.clients, '2.4GHz');
    parseCollection(payload.data, '2.4GHz');

    return Array.from(seenMacs.values());
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
}

export const routerApiService = new RouterApiService();